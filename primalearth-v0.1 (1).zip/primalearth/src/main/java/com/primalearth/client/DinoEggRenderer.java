package com.primalearth.client;

import com.primalearth.PrimalEarth;
import com.primalearth.entity.dinosaur.DinoEgg;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

/** Egg renderer: one shared model, one texture per species. */
public class DinoEggRenderer extends GeoEntityRenderer<DinoEgg> {
    public DinoEggRenderer(EntityRendererProvider.Context context) {
        super(context, new Model());
        this.shadowRadius = 0.25F;
    }

    private static class Model extends GeoModel<DinoEgg> {
        @Override
        public ResourceLocation getModelResource(DinoEgg egg) {
            return PrimalEarth.id("geo/entity/dino_egg.geo.json");
        }

        @Override
        public ResourceLocation getTextureResource(DinoEgg egg) {
            return PrimalEarth.id("textures/entity/egg_" + egg.species().id + ".png");
        }

        @Override
        public ResourceLocation getAnimationResource(DinoEgg egg) {
            return PrimalEarth.id("animations/entity/dino_egg.animation.json");
        }
    }
}
