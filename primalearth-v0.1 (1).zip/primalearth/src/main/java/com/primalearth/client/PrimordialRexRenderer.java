package com.primalearth.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.primalearth.PrimalEarth;
import com.primalearth.entity.kaiju.PrimordialRex;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.model.DefaultedEntityGeoModel;
import software.bernie.geckolib.renderer.GeoEntityRenderer;
import software.bernie.geckolib.renderer.layer.AutoGlowingGeoLayer;

/** The model is authored at half size (higher texture detail) and drawn at 2x: about 18.5 blocks tall. */
public class PrimordialRexRenderer extends GeoEntityRenderer<PrimordialRex> {
    private static final float MODEL_SCALE = 2.0F;

    public PrimordialRexRenderer(EntityRendererProvider.Context context) {
        super(context, new DefaultedEntityGeoModel<>(PrimalEarth.id("primordial_rex"), true));
        this.shadowRadius = 4.0F;
        // glowing crystals and eyes come from textures/entity/primordial_rex_glowmask.png
        addRenderLayer(new AutoGlowingGeoLayer<>(this));
    }

    @Override
    public void render(PrimordialRex entity, float entityYaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource bufferSource, int packedLight) {
        poseStack.pushPose();
        poseStack.scale(MODEL_SCALE, MODEL_SCALE, MODEL_SCALE);
        super.render(entity, entityYaw, partialTick, poseStack, bufferSource, packedLight);
        poseStack.popPose();
    }
}
