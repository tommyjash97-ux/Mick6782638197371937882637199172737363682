package com.primalearth.client;

import com.primalearth.PrimalEarth;
import com.primalearth.registry.ModEntities;
import net.minecraft.client.renderer.entity.EntityRenderers;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = PrimalEarth.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientEvents {
    private ClientEvents() {}

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        ModEntities.DINOSAURS.forEach((species, type) ->
                event.registerEntityRenderer(type.get(), ctx -> new DinosaurRenderer(ctx, species)));
        event.registerEntityRenderer(ModEntities.DINO_EGG.get(), DinoEggRenderer::new);
        event.registerEntityRenderer(ModEntities.PRIMORDIAL_REX.get(), PrimordialRexRenderer::new);
    }
}
