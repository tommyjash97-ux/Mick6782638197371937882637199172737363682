package com.primalearth.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.primalearth.PrimalEarth;
import com.primalearth.entity.dinosaur.Dinosaur;
import com.primalearth.entity.dinosaur.DinosaurSpecies;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.model.DefaultedEntityGeoModel;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

/** Renders a dinosaur with its own GeckoLib model, scaled by growth stage. */
public class DinosaurRenderer extends GeoEntityRenderer<Dinosaur> {
    public DinosaurRenderer(EntityRendererProvider.Context context, DinosaurSpecies species) {
        super(context, new DefaultedEntityGeoModel<>(PrimalEarth.id(species.id), true));
        this.shadowRadius = species.width * 0.45F;
    }

    @Override
    public void render(Dinosaur entity, float entityYaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource bufferSource, int packedLight) {
        float s = entity.renderScale();
        poseStack.pushPose();
        poseStack.scale(s, s, s);
        super.render(entity, entityYaw, partialTick, poseStack, bufferSource, packedLight);
        poseStack.popPose();
    }
}
