package com.primalearth.genetics;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;

/**
 * Inheritable traits. Every value is a multiplier around 1.0 (or 0..1 for temperament).
 * Offspring = average of both parents + small mutation, so change accumulates over generations.
 */
public final class DinoGenes {
    public static final float MUTATION = 0.04F;

    public float size = 1.0F;
    public float speed = 1.0F;
    public float stamina = 1.0F;
    public float temperament = 0.5F;   // 0 = calm, 1 = aggressive
    public float intelligence = 0.5F;
    public float adaptation = 0.5F;
    public float colorVariation = 0.5F;
    public int generation = 0;

    public static DinoGenes random(RandomSource r) {
        DinoGenes g = new DinoGenes();
        g.size = 0.92F + r.nextFloat() * 0.16F;
        g.speed = 0.94F + r.nextFloat() * 0.12F;
        g.stamina = 0.9F + r.nextFloat() * 0.2F;
        g.temperament = r.nextFloat();
        g.intelligence = r.nextFloat();
        g.adaptation = r.nextFloat();
        g.colorVariation = r.nextFloat();
        return g;
    }

    public static DinoGenes inherit(DinoGenes a, DinoGenes b, RandomSource r) {
        DinoGenes g = new DinoGenes();
        g.size = mutate(avg(a.size, b.size), r, 0.8F, 1.25F);
        g.speed = mutate(avg(a.speed, b.speed), r, 0.8F, 1.25F);
        g.stamina = mutate(avg(a.stamina, b.stamina), r, 0.7F, 1.4F);
        g.temperament = mutate(avg(a.temperament, b.temperament), r, 0F, 1F);
        g.intelligence = mutate(avg(a.intelligence, b.intelligence), r, 0F, 1F);
        g.adaptation = mutate(avg(a.adaptation, b.adaptation), r, 0F, 1F);
        g.colorVariation = mutate(avg(a.colorVariation, b.colorVariation), r, 0F, 1F);
        g.generation = Math.max(a.generation, b.generation) + 1;
        return g;
    }

    private static float avg(float a, float b) {
        return (a + b) * 0.5F;
    }

    private static float mutate(float v, RandomSource r, float min, float max) {
        return Mth.clamp(v + (r.nextFloat() * 2F - 1F) * MUTATION, min, max);
    }

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        t.putFloat("Size", size);
        t.putFloat("Speed", speed);
        t.putFloat("Stamina", stamina);
        t.putFloat("Temperament", temperament);
        t.putFloat("Intelligence", intelligence);
        t.putFloat("Adaptation", adaptation);
        t.putFloat("Color", colorVariation);
        t.putInt("Generation", generation);
        return t;
    }

    public static DinoGenes load(CompoundTag t) {
        DinoGenes g = new DinoGenes();
        if (t.contains("Size")) g.size = t.getFloat("Size");
        if (t.contains("Speed")) g.speed = t.getFloat("Speed");
        if (t.contains("Stamina")) g.stamina = t.getFloat("Stamina");
        if (t.contains("Temperament")) g.temperament = t.getFloat("Temperament");
        if (t.contains("Intelligence")) g.intelligence = t.getFloat("Intelligence");
        if (t.contains("Adaptation")) g.adaptation = t.getFloat("Adaptation");
        if (t.contains("Color")) g.colorVariation = t.getFloat("Color");
        g.generation = t.getInt("Generation");
        return g;
    }
}
