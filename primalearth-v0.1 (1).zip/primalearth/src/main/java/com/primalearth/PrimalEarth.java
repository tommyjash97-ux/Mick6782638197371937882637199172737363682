package com.primalearth;

import com.mojang.logging.LogUtils;
import com.primalearth.config.PrimalConfig;
import com.primalearth.registry.ModBlockEntities;
import com.primalearth.registry.ModBlocks;
import com.primalearth.registry.ModCreativeTabs;
import com.primalearth.registry.ModEntities;
import com.primalearth.registry.ModItems;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

/**
 * PRIMAL EARTH: SUPER GOD ULTIMATE - mod entry point.
 * Phase 1: registries, configuration and project foundation.
 */
@Mod(PrimalEarth.MOD_ID)
public class PrimalEarth {
    public static final String MOD_ID = "primalearth";
    public static final Logger LOGGER = LogUtils.getLogger();

    public PrimalEarth() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();

        ModItems.ITEMS.register(modBus);
        ModBlocks.BLOCKS.register(modBus);
        ModBlockEntities.BLOCK_ENTITIES.register(modBus);
        ModEntities.ENTITY_TYPES.register(modBus);
        ModCreativeTabs.TABS.register(modBus);

        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, PrimalConfig.COMMON_SPEC, "primalearth-common.toml");
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, PrimalConfig.CLIENT_SPEC, "primalearth-client.toml");

        modBus.addListener(this::commonSetup);
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        LOGGER.info("Primal Earth initialised (Phase 1 foundation)");
    }

    public static ResourceLocation id(String path) {
        return new ResourceLocation(MOD_ID, path);
    }
}
