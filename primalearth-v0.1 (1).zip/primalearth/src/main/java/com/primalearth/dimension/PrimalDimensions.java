package com.primalearth.dimension;

import com.primalearth.PrimalEarth;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.dimension.DimensionType;

/** Resource keys for primalearth:primal_dimension. The JSON definitions come with the dimension phase. */
public final class PrimalDimensions {
    public static final ResourceKey<Level> PRIMAL_LEVEL =
            ResourceKey.create(Registries.DIMENSION, PrimalEarth.id("primal_dimension"));
    public static final ResourceKey<DimensionType> PRIMAL_TYPE =
            ResourceKey.create(Registries.DIMENSION_TYPE, PrimalEarth.id("primal_dimension"));

    private PrimalDimensions() {}
}
