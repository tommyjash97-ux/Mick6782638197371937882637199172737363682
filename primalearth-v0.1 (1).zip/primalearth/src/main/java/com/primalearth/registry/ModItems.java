package com.primalearth.registry;

import com.primalearth.PrimalEarth;
import com.primalearth.item.TooltipItem;
import com.primalearth.entity.dinosaur.DinosaurSpecies;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.BlockItem;
import net.minecraftforge.common.ForgeSpawnEggItem;
import java.util.EnumMap;
import java.util.Map;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/** Item registry. Items are grouped by creative tab through the two lists below. */
public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, PrimalEarth.MOD_ID);

    // Must be declared before the items so they are initialised first.
    public static final List<Supplier<Item>> TIME_TRAVEL_TAB = new ArrayList<>();
    public static final List<Supplier<Item>> RESEARCH_TAB = new ArrayList<>();
    public static final List<Supplier<Item>> CREATURE_TAB = new ArrayList<>();

    // --- Chronos Gate required components (tab: Time Travel) ---
    public static final RegistryObject<Item> CHRONOS_CORE = timeTravel("chronos_core", Rarity.EPIC, 1);
    public static final RegistryObject<Item> TEMPORAL_CRYSTAL = timeTravel("temporal_crystal", Rarity.RARE, 16);
    public static final RegistryObject<Item> ANCIENT_GEAR = timeTravel("ancient_gear", Rarity.UNCOMMON, 16);
    public static final RegistryObject<Item> ENERGY_CONDUCTOR = timeTravel("energy_conductor", Rarity.UNCOMMON, 16);
    public static final RegistryObject<Item> TIME_STABILIZER = timeTravel("time_stabilizer", Rarity.RARE, 1);
    public static final RegistryObject<Item> PORTAL_CONTROLLER = timeTravel("portal_controller", Rarity.RARE, 1);
    public static final RegistryObject<Item> ANCIENT_BLUEPRINT = timeTravel("ancient_blueprint", Rarity.EPIC, 1);
    public static final RegistryObject<Item> QUANTUM_POWER_CELL = timeTravel("quantum_power_cell", Rarity.EPIC, 1);

    // --- Fossils and research (tab: Research & Fossils) ---
    public static final RegistryObject<Item> FOSSIL_FRAGMENT = research("fossil_fragment", Rarity.COMMON, 64);
    public static final RegistryObject<Item> DNA_SAMPLE = research("dna_sample", Rarity.UNCOMMON, 16);
    public static final RegistryObject<Item> SPECIMEN_CONTAINER = research("specimen_container", Rarity.COMMON, 16);
    public static final RegistryObject<Item> SCIENTIFIC_NOTES = research("scientific_notes", Rarity.UNCOMMON, 16);

    // --- Creatures (tab: Creatures) ---
    public static final RegistryObject<Item> RAW_DINO_MEAT = creature("raw_dino_meat", () -> new Item(
            new Item.Properties().food(new FoodProperties.Builder().nutrition(3).saturationMod(0.3F).meat().build())));
    public static final RegistryObject<Item> COOKED_DINO_MEAT = creature("cooked_dino_meat", () -> new Item(
            new Item.Properties().food(new FoodProperties.Builder().nutrition(8).saturationMod(0.8F).meat().build())));

    public static final Map<DinosaurSpecies, RegistryObject<Item>> SPAWN_EGGS = new EnumMap<>(DinosaurSpecies.class);

    static {
        for (DinosaurSpecies s : DinosaurSpecies.values()) {
            SPAWN_EGGS.put(s, creature(s.id + "_spawn_egg", () -> new ForgeSpawnEggItem(
                    ModEntities.DINOSAURS.get(s), s.eggPrimary, s.eggSecondary, new Item.Properties())));
        }
    }

    public static final RegistryObject<Item> PRIMORDIAL_CRYSTAL = creature("primordial_crystal", () ->
            new TooltipItem(new Item.Properties().stacksTo(16).rarity(Rarity.EPIC)));
    public static final RegistryObject<Item> PRIMORDIAL_REX_SPAWN_EGG = creature("primordial_rex_spawn_egg", () ->
            new ForgeSpawnEggItem(ModEntities.PRIMORDIAL_REX, 0x22382A, 0x5AD8FF, new Item.Properties().rarity(Rarity.EPIC)));

    private static RegistryObject<Item> creature(String name, Supplier<Item> factory) {
        RegistryObject<Item> item = ITEMS.register(name, factory);
        CREATURE_TAB.add(item);
        return item;
    }

    // --- Gate blocks as items ---
    public static final RegistryObject<Item> CHRONOS_FRAME = blockItem("chronos_frame", ModBlocks.CHRONOS_FRAME);
    public static final RegistryObject<Item> CHRONOS_CONTROLLER = blockItem("chronos_controller", ModBlocks.CHRONOS_CONTROLLER);

    private static RegistryObject<Item> blockItem(String name, Supplier<? extends Block> block) {
        RegistryObject<Item> item = ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties()));
        TIME_TRAVEL_TAB.add(item);
        return item;
    }

    private static RegistryObject<Item> timeTravel(String name, Rarity rarity, int stackSize) {
        RegistryObject<Item> item = register(name, rarity, stackSize);
        TIME_TRAVEL_TAB.add(item);
        return item;
    }

    private static RegistryObject<Item> research(String name, Rarity rarity, int stackSize) {
        RegistryObject<Item> item = register(name, rarity, stackSize);
        RESEARCH_TAB.add(item);
        return item;
    }

    private static RegistryObject<Item> register(String name, Rarity rarity, int stackSize) {
        return ITEMS.register(name, () ->
                new TooltipItem(new Item.Properties().stacksTo(stackSize).rarity(rarity)));
    }

    private ModItems() {}
}
