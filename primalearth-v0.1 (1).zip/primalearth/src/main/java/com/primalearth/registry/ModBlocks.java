package com.primalearth.registry;

import com.primalearth.PrimalEarth;
import com.primalearth.time_travel.portal.ChronosControllerBlock;
import com.primalearth.time_travel.portal.ChronosPortalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, PrimalEarth.MOD_ID);

    public static final RegistryObject<Block> CHRONOS_FRAME = BLOCKS.register("chronos_frame", () ->
            new Block(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.METAL)
                    .strength(5.0F, 1200.0F)
                    .sound(SoundType.METAL)
                    .requiresCorrectToolForDrops()));

    public static final RegistryObject<Block> CHRONOS_CONTROLLER = BLOCKS.register("chronos_controller", () ->
            new ChronosControllerBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.METAL)
                    .strength(5.0F, 1200.0F)
                    .sound(SoundType.METAL)
                    .requiresCorrectToolForDrops()
                    .lightLevel(s -> s.getValue(ChronosControllerBlock.ACTIVE) ? 12 : 0)));

    public static final RegistryObject<Block> CHRONOS_PORTAL = BLOCKS.register("chronos_portal", ChronosPortalBlock::new);

    private ModBlocks() {}
}
