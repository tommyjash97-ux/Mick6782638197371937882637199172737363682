package com.primalearth.registry;

import com.primalearth.PrimalEarth;
import com.primalearth.time_travel.portal.ChronosControllerBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, PrimalEarth.MOD_ID);

    public static final RegistryObject<BlockEntityType<ChronosControllerBlockEntity>> CHRONOS_CONTROLLER =
            BLOCK_ENTITIES.register("chronos_controller", () ->
                    BlockEntityType.Builder.of(ChronosControllerBlockEntity::new, ModBlocks.CHRONOS_CONTROLLER.get())
                            .build(null));

    private ModBlockEntities() {}
}
