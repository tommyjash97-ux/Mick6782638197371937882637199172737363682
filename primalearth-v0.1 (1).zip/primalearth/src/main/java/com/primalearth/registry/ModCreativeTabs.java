package com.primalearth.registry;

import com.primalearth.PrimalEarth;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

/** Creative tabs. Creature and equipment tabs will be added when those items exist. */
public final class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, PrimalEarth.MOD_ID);

    public static final RegistryObject<CreativeModeTab> TIME_TRAVEL = TABS.register("time_travel", () ->
            CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup." + PrimalEarth.MOD_ID + ".time_travel"))
                    .icon(() -> new ItemStack(ModItems.CHRONOS_CORE.get()))
                    .displayItems((params, output) ->
                            ModItems.TIME_TRAVEL_TAB.forEach(item -> output.accept(item.get())))
                    .build());

    public static final RegistryObject<CreativeModeTab> RESEARCH = TABS.register("research", () ->
            CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup." + PrimalEarth.MOD_ID + ".research"))
                    .icon(() -> new ItemStack(ModItems.FOSSIL_FRAGMENT.get()))
                    .displayItems((params, output) ->
                            ModItems.RESEARCH_TAB.forEach(item -> output.accept(item.get())))
                    .build());

    public static final RegistryObject<CreativeModeTab> CREATURES = TABS.register("creatures", () ->
            CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup." + PrimalEarth.MOD_ID + ".creatures"))
                    .icon(() -> new ItemStack(ModItems.SPAWN_EGGS.get(
                            com.primalearth.entity.dinosaur.DinosaurSpecies.TYRANNOSAURUS).get()))
                    .displayItems((params, output) ->
                            ModItems.CREATURE_TAB.forEach(item -> output.accept(item.get())))
                    .build());

    private ModCreativeTabs() {}
}
