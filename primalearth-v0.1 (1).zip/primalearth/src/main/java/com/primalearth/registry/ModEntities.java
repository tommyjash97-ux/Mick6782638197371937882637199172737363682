package com.primalearth.registry;

import com.primalearth.PrimalEarth;
import com.primalearth.entity.dinosaur.DinoEgg;
import com.primalearth.entity.dinosaur.Dinosaur;
import com.primalearth.entity.dinosaur.DinosaurSpecies;
import com.primalearth.entity.kaiju.PrimordialRex;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.EnumMap;
import java.util.Map;

/** Entity registry: one type per starter dinosaur plus the egg. */
public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, PrimalEarth.MOD_ID);

    public static final Map<DinosaurSpecies, RegistryObject<EntityType<Dinosaur>>> DINOSAURS =
            new EnumMap<>(DinosaurSpecies.class);

    static {
        for (DinosaurSpecies s : DinosaurSpecies.values()) {
            DINOSAURS.put(s, ENTITY_TYPES.register(s.id, () ->
                    EntityType.Builder.<Dinosaur>of((type, level) -> new Dinosaur(type, level, s), MobCategory.CREATURE)
                            .sized(s.width, s.height)
                            .clientTrackingRange(10)
                            .build(PrimalEarth.MOD_ID + ":" + s.id)));
        }
    }

    public static final RegistryObject<EntityType<PrimordialRex>> PRIMORDIAL_REX = ENTITY_TYPES.register("primordial_rex", () ->
            EntityType.Builder.<PrimordialRex>of(PrimordialRex::new, MobCategory.MONSTER)
                    .sized(6.0F, 18.5F)
                    .fireImmune()
                    .clientTrackingRange(16)
                    .build(PrimalEarth.MOD_ID + ":primordial_rex"));

    public static final RegistryObject<EntityType<DinoEgg>> DINO_EGG = ENTITY_TYPES.register("dino_egg", () ->
            EntityType.Builder.<DinoEgg>of(DinoEgg::new, MobCategory.MISC)
                    .sized(0.5F, 0.6F)
                    .clientTrackingRange(8)
                    .updateInterval(20)
                    .build(PrimalEarth.MOD_ID + ":dino_egg"));

    private ModEntities() {}
}
