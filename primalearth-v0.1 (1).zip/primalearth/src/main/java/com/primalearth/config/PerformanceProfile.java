package com.primalearth.config;

/**
 * Performance presets. Values are starting points, not guarantees: tune them by testing on real hardware.
 *
 * @param densityMultiplier     scales creature spawn density
 * @param aiTickInterval        creature AI "think" runs once per this many ticks
 * @param regionPopulationCap   max creatures tracked per simulation region
 * @param memoryEntriesPerCreature max memory entries per creature
 */
public enum PerformanceProfile {
    LOW(0.4, 20, 40, 4),
    BALANCED(0.7, 10, 80, 8),
    ULTRA(1.0, 5, 150, 12),
    EXTREME(1.5, 2, 300, 16);

    public final double densityMultiplier;
    public final int aiTickInterval;
    public final int regionPopulationCap;
    public final int memoryEntriesPerCreature;

    PerformanceProfile(double densityMultiplier, int aiTickInterval, int regionPopulationCap, int memoryEntriesPerCreature) {
        this.densityMultiplier = densityMultiplier;
        this.aiTickInterval = aiTickInterval;
        this.regionPopulationCap = regionPopulationCap;
        this.memoryEntriesPerCreature = memoryEntriesPerCreature;
    }
}
