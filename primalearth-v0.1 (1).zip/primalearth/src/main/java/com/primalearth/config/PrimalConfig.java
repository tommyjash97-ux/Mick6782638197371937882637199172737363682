package com.primalearth.config;

import net.minecraftforge.common.ForgeConfigSpec;
import org.apache.commons.lang3.tuple.Pair;

/** Central configuration. COMMON is server-authoritative; CLIENT only affects local visuals/audio. */
public final class PrimalConfig {
    public static final Common COMMON;
    public static final ForgeConfigSpec COMMON_SPEC;
    public static final Client CLIENT;
    public static final ForgeConfigSpec CLIENT_SPEC;

    static {
        Pair<Common, ForgeConfigSpec> common = new ForgeConfigSpec.Builder().configure(Common::new);
        COMMON = common.getLeft();
        COMMON_SPEC = common.getRight();

        Pair<Client, ForgeConfigSpec> client = new ForgeConfigSpec.Builder().configure(Client::new);
        CLIENT = client.getLeft();
        CLIENT_SPEC = client.getRight();
    }

    public static final class Common {
        public final ForgeConfigSpec.EnumValue<PerformanceProfile> performanceProfile;
        public final ForgeConfigSpec.DoubleValue creatureSpawnRate;
        public final ForgeConfigSpec.IntValue populationCapOverride;
        public final ForgeConfigSpec.IntValue aiComplexity;
        public final ForgeConfigSpec.DoubleValue ecosystemSimulationSpeed;
        public final ForgeConfigSpec.BooleanValue reproductionEnabled;
        public final ForgeConfigSpec.DoubleValue growthRateMultiplier;
        public final ForgeConfigSpec.DoubleValue bossHealth;
        public final ForgeConfigSpec.DoubleValue bossDamageMultiplier;
        public final ForgeConfigSpec.IntValue portalEnergyRequirement;
        public final ForgeConfigSpec.IntValue portalOpenSeconds;
        public final ForgeConfigSpec.BooleanValue dimensionTravelEnabled;
        public final ForgeConfigSpec.BooleanValue portalActivationOpOnly;
        public final ForgeConfigSpec.BooleanValue naturalDisastersEnabled;
        public final ForgeConfigSpec.IntValue disasterWarningSeconds;
        public final ForgeConfigSpec.BooleanValue worldEventsEnabled;
        public final ForgeConfigSpec.DoubleValue structureSpawnFrequency;

        Common(ForgeConfigSpec.Builder b) {
            b.push("performance");
            performanceProfile = b.comment("LOW, BALANCED, ULTRA or EXTREME. Controls creature density, AI interval and population caps.")
                    .defineEnum("performanceProfile", PerformanceProfile.BALANCED);
            populationCapOverride = b.comment("Max creatures per simulation region. 0 = use the performance profile value.")
                    .defineInRange("populationCapOverride", 0, 0, 2000);
            aiComplexity = b.comment("1 = basic (wander/eat/flee), 2 = herds and memory, 3 = full (packs, territory, personality).")
                    .defineInRange("aiComplexity", 3, 1, 3);
            b.pop();

            b.push("creatures");
            creatureSpawnRate = b.comment("Multiplier for natural creature spawn rates.")
                    .defineInRange("creatureSpawnRate", 1.0, 0.0, 5.0);
            reproductionEnabled = b.comment("Allow creatures to breed and lay eggs.")
                    .define("reproductionEnabled", true);
            growthRateMultiplier = b.comment("Multiplier for life-stage growth speed.")
                    .defineInRange("growthRateMultiplier", 1.0, 0.1, 10.0);
            b.pop();

            b.push("ecosystem");
            ecosystemSimulationSpeed = b.comment("Speed of the living-planet regional simulation.")
                    .defineInRange("ecosystemSimulationSpeed", 1.0, 0.1, 10.0);
            b.pop();

            b.push("bosses");
            bossHealth = b.comment("Primordial Rex base health (default 1200).")
                    .defineInRange("bossHealth", 1200.0, 100.0, 100000.0);
            bossDamageMultiplier = b.comment("Multiplier for boss attack damage (base 12-20).")
                    .defineInRange("bossDamageMultiplier", 1.0, 0.1, 10.0);
            b.pop();

            b.push("time_travel");
            portalEnergyRequirement = b.comment("Energy units needed to activate the Chronos Gate.")
                    .defineInRange("portalEnergyRequirement", 10000, 100, 10_000_000);
            portalOpenSeconds = b.comment("How long the Chronos Gate stays open after activation.")
                    .defineInRange("portalOpenSeconds", 60, 5, 3600);
            dimensionTravelEnabled = b.comment("Master switch for travel to the Primal Dimension.")
                    .define("dimensionTravelEnabled", true);
            portalActivationOpOnly = b.comment("Multiplayer: only operators may activate the Chronos Gate.")
                    .define("portalActivationOpOnly", false);
            b.pop();

            b.push("world");
            naturalDisastersEnabled = b.comment("Enable storms, droughts and volcanic eruptions.")
                    .define("naturalDisastersEnabled", true);
            disasterWarningSeconds = b.comment("Warning time before a destructive disaster starts.")
                    .defineInRange("disasterWarningSeconds", 30, 5, 600);
            worldEventsEnabled = b.comment("Enable dynamic world events (migrations, nesting season, ...).")
                    .define("worldEventsEnabled", true);
            structureSpawnFrequency = b.comment("Multiplier for Overworld discovery structure frequency.")
                    .defineInRange("structureSpawnFrequency", 1.0, 0.0, 5.0);
            b.pop();
        }

        public int effectivePopulationCap() {
            int override = populationCapOverride.get();
            return override > 0 ? override : performanceProfile.get().regionPopulationCap;
        }

        public int effectiveAiTickInterval() {
            return performanceProfile.get().aiTickInterval;
        }
    }

    public static final class Client {
        public final ForgeConfigSpec.DoubleValue particleMultiplier;
        public final ForgeConfigSpec.IntValue creatureSoundDistance;

        Client(ForgeConfigSpec.Builder b) {
            particleMultiplier = b.comment("Multiplier for mod particle counts.")
                    .defineInRange("particleMultiplier", 1.0, 0.0, 1.0);
            creatureSoundDistance = b.comment("Max distance (blocks) at which creature sounds are played.")
                    .defineInRange("creatureSoundDistance", 64, 16, 128);
        }
    }

    private PrimalConfig() {}
}
