package com.primalearth.entity.dinosaur;

import com.primalearth.config.PrimalConfig;
import com.primalearth.genetics.DinoGenes;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.NetworkHooks;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

/** A laid dinosaur egg: incubates, wobbles shortly before hatching, then becomes a hatchling. */
public class DinoEgg extends Entity implements GeoEntity {
    private static final EntityDataAccessor<Integer> DATA_SPECIES =
            SynchedEntityData.defineId(DinoEgg.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> DATA_HATCHING =
            SynchedEntityData.defineId(DinoEgg.class, EntityDataSerializers.BOOLEAN);
    private static final int HATCH_WARNING_TICKS = 300;

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private DinoGenes genes = new DinoGenes();
    private double remaining = DinosaurSpecies.DAY;

    public DinoEgg(EntityType<? extends DinoEgg> type, Level level) {
        super(type, level);
    }

    public void setup(DinosaurSpecies species, DinoGenes genes) {
        this.entityData.set(DATA_SPECIES, species.ordinal());
        this.genes = genes;
        this.remaining = species.incubationTicks;
    }

    public DinosaurSpecies species() {
        return DinosaurSpecies.byIndex(entityData.get(DATA_SPECIES));
    }

    public boolean isHatching() {
        return entityData.get(DATA_HATCHING);
    }

    @Override
    public void tick() {
        super.tick();
        if (!onGround()) {
            setDeltaMovement(getDeltaMovement().add(0, -0.04, 0));
        } else {
            setDeltaMovement(0, 0, 0);
        }
        move(MoverType.SELF, getDeltaMovement());

        if (level().isClientSide) return;
        remaining -= PrimalConfig.COMMON.growthRateMultiplier.get();
        if (remaining <= HATCH_WARNING_TICKS && !isHatching()) entityData.set(DATA_HATCHING, true);
        if (remaining <= 0 && level() instanceof ServerLevel sl) hatch(sl);
    }

    private void hatch(ServerLevel sl) {
        Dinosaur baby = com.primalearth.registry.ModEntities.DINOSAURS.get(species()).get().create(sl);
        if (baby != null) {
            baby.moveTo(getX(), getY(), getZ(), random.nextFloat() * 360F, 0F);
            baby.initHatchling(genes);
            sl.addFreshEntity(baby);
            sl.playSound(null, blockPosition(), SoundEvents.TURTLE_EGG_HATCH, SoundSource.NEUTRAL, 1.0F, 0.8F);
        }
        discard();
    }

    @Override
    public boolean isPickable() {
        return true;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (!level().isClientSide && !isRemoved() && !source.is(net.minecraft.tags.DamageTypeTags.IS_FALL)) {
            level().playSound(null, blockPosition(), SoundEvents.TURTLE_EGG_BREAK, SoundSource.NEUTRAL, 1.0F, 0.9F);
            discard();
        }
        return true;
    }

    @Override
    protected void defineSynchedData() {
        entityData.define(DATA_SPECIES, 0);
        entityData.define(DATA_HATCHING, false);
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        entityData.set(DATA_SPECIES, tag.getInt("Species"));
        remaining = tag.getDouble("Remaining");
        genes = DinoGenes.load(tag.getCompound("Genes"));
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putInt("Species", entityData.get(DATA_SPECIES));
        tag.putDouble("Remaining", remaining);
        tag.put("Genes", genes.save());
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "wobble", 0, state ->
                isHatching() ? state.setAndContinue(RawAnimation.begin().thenLoop("animation.dino_egg.hatch"))
                        : PlayState.STOP));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }
}
