package com.primalearth.entity.dinosaur;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;

import java.util.function.Supplier;

/** Static data for the starter species. Tuning values live here so balancing is one file. */
public enum DinosaurSpecies {
    //          id               carn   pack   health speed dmg  w     h     lifeDays popCap  incubDays  eggDays sounds
    TYRANNOSAURUS("tyrannosaurus", true, false, 120, 0.27, 14, 2.6F, 4.4F, 30, 3, 2.0, 6.0,
            () -> SoundEvents.RAVAGER_AMBIENT, () -> SoundEvents.RAVAGER_HURT, () -> SoundEvents.RAVAGER_DEATH,
            () -> SoundEvents.RAVAGER_STEP, 0.55F, 0xD8C58A, 0x5E5A3E),
    SPINOSAURUS("spinosaurus", true, false, 100, 0.26, 12, 2.4F, 3.9F, 28, 3, 2.0, 6.0,
            () -> SoundEvents.RAVAGER_AMBIENT, () -> SoundEvents.RAVAGER_HURT, () -> SoundEvents.RAVAGER_DEATH,
            () -> SoundEvents.RAVAGER_STEP, 0.7F, 0x3E5C62, 0xA84234),
    VELOCIRAPTOR("velociraptor", true, true, 28, 0.36, 5, 1.0F, 1.9F, 14, 8, 1.0, 3.0,
            () -> SoundEvents.FOX_SCREECH, () -> SoundEvents.FOX_HURT, () -> SoundEvents.FOX_DEATH,
            () -> SoundEvents.WOLF_STEP, 0.75F, 0x7E4A2A, 0xD6C098),
    TRICERATOPS("triceratops", false, false, 90, 0.22, 8, 2.2F, 3.4F, 25, 8, 1.5, 4.0,
            () -> SoundEvents.COW_AMBIENT, () -> SoundEvents.COW_HURT, () -> SoundEvents.COW_DEATH,
            () -> SoundEvents.COW_STEP, 0.45F, 0x706A5E, 0xA04C3E),
    BRACHIOSAURUS("brachiosaurus", false, false, 220, 0.18, 6, 3.6F, 7.4F, 40, 6, 2.5, 8.0,
            () -> SoundEvents.ELDER_GUARDIAN_AMBIENT_LAND, () -> SoundEvents.ELDER_GUARDIAN_HURT_LAND,
            () -> SoundEvents.ELDER_GUARDIAN_DEATH_LAND, () -> SoundEvents.COW_STEP, 0.4F, 0x707E64, 0xB0B494);

    public static final int DAY = 24000;

    public final String id;
    public final boolean carnivore;
    public final boolean pack;
    public final double maxHealth;
    public final double speed;
    public final double damage;
    public final float width;
    public final float height;
    public final int lifespanTicks;
    public final int localPopulationCap;
    public final int incubationTicks;
    public final int eggCooldownTicks;
    public final Supplier<SoundEvent> ambient, hurt, death, step;
    public final float voicePitch;
    public final int eggPrimary, eggSecondary;

    DinosaurSpecies(String id, boolean carnivore, boolean pack, double maxHealth, double speed, double damage,
                    float width, float height, int lifeDays, int popCap, double incubDays, double eggDays,
                    Supplier<SoundEvent> ambient, Supplier<SoundEvent> hurt, Supplier<SoundEvent> death,
                    Supplier<SoundEvent> step, float voicePitch, int eggPrimary, int eggSecondary) {
        this.id = id;
        this.carnivore = carnivore;
        this.pack = pack;
        this.maxHealth = maxHealth;
        this.speed = speed;
        this.damage = damage;
        this.width = width;
        this.height = height;
        this.lifespanTicks = lifeDays * DAY;
        this.localPopulationCap = popCap;
        this.incubationTicks = (int) (incubDays * DAY);
        this.eggCooldownTicks = (int) (eggDays * DAY);
        this.ambient = ambient;
        this.hurt = hurt;
        this.death = death;
        this.step = step;
        this.voicePitch = voicePitch;
        this.eggPrimary = eggPrimary;
        this.eggSecondary = eggSecondary;
    }

    /** Fights back when attacked instead of fleeing. */
    public boolean defends() {
        return carnivore || this == TRICERATOPS;
    }

    /** Age (ticks) at which the animal is fully grown. */
    public int adultAge() {
        return (int) (lifespanTicks * 0.2);
    }

    public static DinosaurSpecies byIndex(int i) {
        DinosaurSpecies[] v = values();
        return v[Math.floorMod(i, v.length)];
    }
}
