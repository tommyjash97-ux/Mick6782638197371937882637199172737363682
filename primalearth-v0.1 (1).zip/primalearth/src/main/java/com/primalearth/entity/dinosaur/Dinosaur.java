package com.primalearth.entity.dinosaur;

import com.primalearth.ai.behavior.GrazeGoal;
import com.primalearth.ai.herd.FollowHerdGoal;
import com.primalearth.ai.memory.DinoMemory;
import com.primalearth.config.PrimalConfig;
import com.primalearth.genetics.DinoGenes;
import com.primalearth.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.AvoidEntityGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.Animation;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.List;

/**
 * One class for all starter dinosaurs; the species supplies model, stats and diet.
 * All behaviour runs on the server; the client only receives the growth scale and animations.
 */
public class Dinosaur extends PathfinderMob implements GeoEntity {
    public enum Stage { HATCHLING, JUVENILE, ADOLESCENT, ADULT, ELDER }

    private static final EntityDataAccessor<Float> DATA_SCALE =
            SynchedEntityData.defineId(Dinosaur.class, EntityDataSerializers.FLOAT);
    private static final float HUNGER_PER_SECOND = 0.02F;

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final DinoMemory memory = new DinoMemory();
    private final DinosaurSpecies species;
    private DinoGenes genes;
    private int ageTicks;
    private double ageAccum;
    private float hunger;
    private int eggCooldown;

    public Dinosaur(EntityType<? extends Dinosaur> type, Level level, DinosaurSpecies species) {
        super(type, level);
        this.species = species;
        this.genes = DinoGenes.random(this.random);
        this.hunger = 60 + this.random.nextInt(40);
        this.xpReward = 20 + (int) (species.maxHealth / 10);
        this.setMaxUpStep(1.0F + species.height * 0.12F);
        registerDinoGoals();
        applyGrowth(true);
    }

    public static AttributeSupplier.Builder createAttributes(DinosaurSpecies s) {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, s.maxHealth)
                .add(Attributes.MOVEMENT_SPEED, s.speed)
                .add(Attributes.ATTACK_DAMAGE, s.damage)
                .add(Attributes.ATTACK_KNOCKBACK, 1.2)
                .add(Attributes.FOLLOW_RANGE, 32.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, Math.min(0.9, s.maxHealth / 300.0));
    }

    public static boolean checkSpawn(EntityType<? extends Mob> type, ServerLevelAccessor level, MobSpawnType reason,
                                     BlockPos pos, RandomSource random) {
        if (reason == MobSpawnType.NATURAL && random.nextFloat() > PrimalConfig.COMMON.creatureSpawnRate.get()) {
            return false;
        }
        return Mob.checkMobSpawnRules(type, level, reason, pos, random);
    }

    // ------------------------------------------------------------------ goals

    @Override
    protected void registerGoals() {
        // Intentionally empty: Mob's constructor calls this before 'species' exists.
        // Goals are registered in registerDinoGoals() from our own constructor.
    }

    private void registerDinoGoals() {
        int complexity = PrimalConfig.COMMON.aiComplexity.get();
        goalSelector.addGoal(0, new FloatGoal(this));

        if (species.defends()) {
            goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.25, true));
            targetSelector.addGoal(1, new HurtByTargetGoal(this));
        } else {
            goalSelector.addGoal(1, new PanicGoal(this, 1.6));
            goalSelector.addGoal(2, new AvoidEntityGoal<>(this, Dinosaur.class, 14.0F, 1.0, 1.5,
                    e -> e instanceof Dinosaur d && d.species.carnivore));
        }
        if (species.carnivore) {
            int interval = Math.max(10, aiInterval() * 2);
            targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, LivingEntity.class, interval, true, false, this::isPrey));
        } else {
            goalSelector.addGoal(4, new GrazeGoal(this));
        }
        if (complexity >= 2 && (species.pack || !species.carnivore)) {
            goalSelector.addGoal(3, new FollowHerdGoal(this, 1.0));
        }
        goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 0.8));
        goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 12.0F));
        goalSelector.addGoal(8, new RandomLookAroundGoal(this));
    }

    private boolean isPrey(LivingEntity e) {
        if (!species.carnivore || e == this || !e.isAlive() || stage() == Stage.HATCHLING) return false;
        if (e instanceof Player p) {
            return !p.isCreative() && !p.isSpectator() && (hunger < 60 || genes.temperament > 0.55F);
        }
        if (e instanceof Dinosaur d) {
            return !d.species.carnivore && hunger < 85 && d.getMaxHealth() < getMaxHealth() * 1.5F;
        }
        if (e instanceof Animal || e instanceof AbstractVillager) return hunger < 80;
        return false;
    }

    public int aiInterval() {
        return PrimalConfig.COMMON.effectiveAiTickInterval();
    }

    // ------------------------------------------------------------ life cycle

    public DinosaurSpecies species() {
        return species;
    }

    public int ageTicks() {
        return ageTicks;
    }

    public DinoGenes genes() {
        return genes;
    }

    public DinoMemory memory() {
        return memory;
    }

    public float getHunger() {
        return hunger;
    }

    public void eat(float amount) {
        hunger = Math.min(100F, hunger + amount);
    }

    public void rememberFood(BlockPos pos) {
        if (PrimalConfig.COMMON.aiComplexity.get() >= 2) {
            memory.remember(DinoMemory.Kind.FOOD, pos, level().getGameTime(), 6000,
                    com.primalearth.config.PerformanceProfile.BALANCED.memoryEntriesPerCreature);
        }
    }

    public Stage stage() {
        float f = ageTicks / (float) species.lifespanTicks;
        if (f < 0.04F) return Stage.HATCHLING;
        if (f < 0.12F) return Stage.JUVENILE;
        if (f < 0.20F) return Stage.ADOLESCENT;
        if (f < 0.85F) return Stage.ADULT;
        return Stage.ELDER;
    }

    /** 0 (just hatched) to 1 (fully grown). */
    public float growth() {
        return Math.min(1.0F, ageTicks / (float) species.adultAge());
    }

    public float scale() {
        return (0.2F + 0.8F * growth()) * genes.size;
    }

    public float renderScale() {
        return entityData.get(DATA_SCALE);
    }

    /** Called for creatures that come out of an egg. */
    public void initHatchling(DinoGenes inherited) {
        this.genes = inherited;
        this.ageTicks = 0;
        this.hunger = 70;
        applyGrowth(true);
    }

    public void applyGrowth(boolean fullHeal) {
        float g = growth();
        float statScale = 0.25F + 0.75F * g;
        float ratio = getMaxHealth() > 0 ? getHealth() / getMaxHealth() : 1F;
        setBase(Attributes.MAX_HEALTH, species.maxHealth * genes.stamina * statScale);
        setBase(Attributes.ATTACK_DAMAGE, species.damage * statScale);
        setBase(Attributes.MOVEMENT_SPEED, species.speed * genes.speed * (g < 0.5F ? 1.15F : 1.0F));
        setHealth(fullHeal ? getMaxHealth() : Math.max(1F, getMaxHealth() * ratio));
        entityData.set(DATA_SCALE, scale());
    }

    private void setBase(Attribute attribute, double value) {
        if (getAttribute(attribute) != null) getAttribute(attribute).setBaseValue(value);
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (level().isClientSide) return;

        ageAccum += PrimalConfig.COMMON.growthRateMultiplier.get();
        int whole = (int) ageAccum;
        ageAccum -= whole;
        ageTicks += whole;
        if (eggCooldown > 0) eggCooldown--;

        if (tickCount % 20 == 0) hunger = Math.max(0F, hunger - HUNGER_PER_SECOND);
        if ((tickCount + getId()) % 100 == 0) slowTick();
    }

    /** Runs once every 5 seconds: growth sync, starvation, old age, reproduction. */
    private void slowTick() {
        if (!(level() instanceof ServerLevel sl)) return;
        if (Math.abs(scale() - entityData.get(DATA_SCALE)) > 0.004F) applyGrowth(false);

        if (hunger <= 0F) {
            hurt(damageSources().starve(), 2F);
        } else if (hunger > 50F && getHealth() < getMaxHealth()) {
            heal(1F + getMaxHealth() * 0.01F);
        }
        if (ageTicks > species.lifespanTicks && random.nextInt(10) == 0) {
            hurt(damageSources().genericKill(), Float.MAX_VALUE);
            return;
        }
        tryReproduce(sl);
    }

    private void tryReproduce(ServerLevel sl) {
        if (!PrimalConfig.COMMON.reproductionEnabled.get()) return;
        if (stage() != Stage.ADULT || eggCooldown > 0 || hunger < 60F) return;

        List<Dinosaur> mates = sl.getEntitiesOfClass(Dinosaur.class, getBoundingBox().inflate(16, 6, 16),
                d -> d != this && d.isAlive() && d.species == species && d.stage() == Stage.ADULT
                        && d.eggCooldown <= 0 && d.hunger >= 60F);
        if (mates.isEmpty()) return;

        // Population control: cap per species within ~96 blocks (scaled by the performance profile / config)
        int cap = Math.max(2, Math.round(species.localPopulationCap * PrimalConfig.COMMON.effectivePopulationCap() / 80.0F));
        int nearby = sl.getEntitiesOfClass(Dinosaur.class, getBoundingBox().inflate(96, 48, 96), d -> d.species == species).size()
                + sl.getEntitiesOfClass(DinoEgg.class, getBoundingBox().inflate(96, 48, 96), e -> e.species() == species).size();
        if (nearby >= cap) return;

        Dinosaur mate = mates.get(0);
        DinoEgg egg = ModEntities.DINO_EGG.get().create(sl);
        if (egg == null) return;
        egg.setup(species, DinoGenes.inherit(genes, mate.genes, random));
        egg.moveTo(getX() + random.nextDouble() - 0.5, getY(), getZ() + random.nextDouble() - 0.5, 0F, 0F);
        sl.addFreshEntity(egg);

        int cooldown = (int) (species.eggCooldownTicks / Math.max(0.1, PrimalConfig.COMMON.growthRateMultiplier.get()));
        eggCooldown = cooldown;
        mate.eggCooldown = cooldown;
        hunger -= 15F;
        mate.hunger -= 15F;
    }

    // --------------------------------------------------------------- combat

    @Override
    public void setTarget(@Nullable LivingEntity target) {
        boolean fresh = target != null && getTarget() == null;
        super.setTarget(target);
        if (fresh && !level().isClientSide) {
            if (species.carnivore && random.nextFloat() < 0.4F) {
                triggerAnim("action", "roar");
                playSound(species.ambient.get(), 1.5F, getVoicePitch() * 0.9F);
            }
            if (species.pack && PrimalConfig.COMMON.aiComplexity.get() >= 3) alertPack(target);
        }
    }

    private void alertPack(LivingEntity target) {
        for (Dinosaur d : level().getEntitiesOfClass(Dinosaur.class, getBoundingBox().inflate(18, 6, 18),
                o -> o != this && o.species == species && o.isAlive() && o.getTarget() == null)) {
            d.setTarget(target);
        }
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        triggerAnim("action", "attack");
        return super.doHurtTarget(target);
    }

    @Override
    public boolean killedEntity(ServerLevel level, LivingEntity victim) {
        if (species.carnivore) {
            eat(Math.min(60F, 20F + victim.getMaxHealth()));
        }
        return super.killedEntity(level, victim);
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (!level().isClientSide && source.getEntity() != null && PrimalConfig.COMMON.aiComplexity.get() >= 2) {
            memory.remember(DinoMemory.Kind.DANGER, source.getEntity().blockPosition(), level().getGameTime(), 2400,
                    com.primalearth.config.PerformanceProfile.BALANCED.memoryEntriesPerCreature);
        }
        return super.hurt(source, amount);
    }

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        if (player.isShiftKeyDown() && held.isEmpty() && hand == InteractionHand.MAIN_HAND) {
            if (!level().isClientSide) {
                player.displayClientMessage(Component.translatable("message.primalearth.dino_info",
                        getType().getDescription(),
                        Component.translatable("stage.primalearth." + stage().name().toLowerCase()),
                        Math.round(hunger), genes.generation), false);
            }
            return InteractionResult.sidedSuccess(level().isClientSide);
        }
        return super.mobInteract(player, hand);
    }

    // ------------------------------------------------------------- spawning

    @Nullable
    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType reason,
                                        @Nullable SpawnGroupData data, @Nullable CompoundTag tag) {
        SpawnGroupData result = super.finalizeSpawn(level, difficulty, reason, data, tag);
        RandomSource r = level.getRandom();
        int life = species.lifespanTicks;
        float roll = r.nextFloat();
        if (reason == MobSpawnType.SPAWN_EGG || reason == MobSpawnType.COMMAND || reason == MobSpawnType.SPAWNER) {
            ageTicks = (int) (life * 0.3F);
        } else if (roll < 0.10F) {
            ageTicks = (int) (life * (0.04F + r.nextFloat() * 0.08F));
        } else if (roll < 0.20F) {
            ageTicks = (int) (life * (0.12F + r.nextFloat() * 0.08F));
        } else if (roll < 0.90F) {
            ageTicks = (int) (life * (0.20F + r.nextFloat() * 0.60F));
        } else {
            ageTicks = (int) (life * (0.85F + r.nextFloat() * 0.10F));
        }
        hunger = 40 + r.nextInt(60);
        genes = DinoGenes.random(r);
        applyGrowth(true);
        return result;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    // --------------------------------------------------------- size / sound

    @Override
    public EntityDimensions getDimensions(Pose pose) {
        if (species == null) return super.getDimensions(pose);
        return EntityDimensions.scalable(species.width, species.height).scale(entityData.get(DATA_SCALE));
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        if (DATA_SCALE.equals(key)) refreshDimensions();
        super.onSyncedDataUpdated(key);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(DATA_SCALE, 1.0F);
    }

    @Nullable
    @Override
    protected SoundEvent getAmbientSound() {
        return species.ambient.get();
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return species.hurt.get();
    }

    @Override
    protected SoundEvent getDeathSound() {
        return species.death.get();
    }

    @Override
    public int getAmbientSoundInterval() {
        return 240;
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        playSound(species.step.get(), Math.min(1.0F, 0.2F + 0.4F * renderScale()), species.voicePitch);
    }

    @Override
    public float getVoicePitch() {
        float s = Math.min(1.0F, renderScale() / Math.max(0.5F, genes.size));
        return species.voicePitch * (1.6F - 0.6F * s);
    }

    // ------------------------------------------------------------ save data

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Age", ageTicks);
        tag.putFloat("Hunger", hunger);
        tag.putInt("EggCooldown", eggCooldown);
        tag.put("Genes", genes.save());
        tag.put("Memory", memory.save());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        ageTicks = tag.getInt("Age");
        hunger = tag.contains("Hunger") ? tag.getFloat("Hunger") : 70F;
        eggCooldown = tag.getInt("EggCooldown");
        if (tag.contains("Genes")) genes = DinoGenes.load(tag.getCompound("Genes"));
        memory.load(tag.getList("Memory", DinoMemory.LIST_TAG));
        applyGrowth(false);
    }

    // ------------------------------------------------------------ animation

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        String p = "animation." + species.id + ".";
        controllers.add(new AnimationController<>(this, "move", 6, this::moveAnimation));
        controllers.add(new AnimationController<>(this, "action", 2, state -> PlayState.STOP)
                .triggerableAnim("attack", RawAnimation.begin().then(p + "attack", Animation.LoopType.PLAY_ONCE))
                .triggerableAnim("eat", RawAnimation.begin().then(p + "eat", Animation.LoopType.PLAY_ONCE))
                .triggerableAnim("roar", RawAnimation.begin().then(p + "roar", Animation.LoopType.PLAY_ONCE)));
    }

    private PlayState moveAnimation(AnimationState<Dinosaur> state) {
        String p = "animation." + species.id + ".";
        if (state.isMoving()) {
            boolean fast = state.getLimbSwingAmount() > 0.55F || isAggressive();
            return state.setAndContinue(RawAnimation.begin().thenLoop(p + (fast ? "run" : "walk")));
        }
        return state.setAndContinue(RawAnimation.begin().thenLoop(p + "idle"));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }
}
