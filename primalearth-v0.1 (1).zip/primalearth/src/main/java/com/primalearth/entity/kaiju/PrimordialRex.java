package com.primalearth.entity.kaiju;

import com.primalearth.config.PrimalConfig;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.Animation;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.EnumMap;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * PRIMORDIAL REX - the first Kaiju boss.
 * Phase 1 Awakening (100-66%): bite, stomp, tail sweep, roar.
 * Phase 2 Predator Rage (66-33%): adds ground charge, rage mode (faster, harder hitting).
 * Phase 3 Primordial Fury (33-0%): adds the energy burst beam, shorter cooldowns.
 * Every special attack has a wind-up with an animation, a sound and a particle telegraph.
 */
public class PrimordialRex extends PathfinderMob implements GeoEntity {
    public enum Ability { NONE, STOMP, TAIL_SWEEP, ROAR, CHARGE, ENERGY_BURST }

    private static final EntityDataAccessor<Integer> DATA_PHASE =
            SynchedEntityData.defineId(PrimordialRex.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> DATA_RAGE =
            SynchedEntityData.defineId(PrimordialRex.class, EntityDataSerializers.BOOLEAN);
    private static final UUID RAGE_SPEED_ID = UUID.fromString("5d6f1c2e-8a43-4b9e-9a57-1c0e5f3b7a10");

    // Wind-up lengths in ticks (they match the animation lengths in the model)
    private static final int STOMP_WINDUP = 28, STOMP_TOTAL = 40;
    private static final int TAIL_WINDUP = 24, TAIL_TOTAL = 36;
    private static final int ROAR_WINDUP = 20, ROAR_TOTAL = 50;
    private static final int CHARGE_WINDUP = 30, CHARGE_RUN = 25, CHARGE_TOTAL = CHARGE_WINDUP + CHARGE_RUN + 40;
    private static final int BURST_WINDUP = 50, BURST_TOTAL = 60;

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final ServerBossEvent bossEvent = new ServerBossEvent(
            Component.translatable("entity.primalearth.primordial_rex"),
            BossEvent.BossBarColor.BLUE, BossEvent.BossBarOverlay.NOTCHED_10);
    private final EnumMap<Ability, Long> readyAt = new EnumMap<>(Ability.class);
    private final Set<Integer> hitThisAbility = new HashSet<>();

    private Ability ability = Ability.NONE;
    private int abilityTick;
    private int globalCooldown = 60;
    private int transitionTicks;
    private int rageTicks;
    private int biteCooldown;
    private int biteDelay;
    private boolean recovering;
    private boolean finalRageUsed;
    private Vec3 lockedDir = Vec3.ZERO;

    public PrimordialRex(EntityType<? extends PrimordialRex> type, Level level) {
        super(type, level);
        this.xpReward = 500;
        this.setMaxUpStep(3.0F);
        this.setPersistenceRequired();
        getAttribute(Attributes.MAX_HEALTH).setBaseValue(PrimalConfig.COMMON.bossHealth.get());
        setHealth(getMaxHealth());
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 1200.0)
                .add(Attributes.MOVEMENT_SPEED, 0.28)
                .add(Attributes.ATTACK_DAMAGE, 16.0)
                .add(Attributes.ARMOR, 8.0)
                .add(Attributes.FOLLOW_RANGE, 64.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new ChaseGoal());
        goalSelector.addGoal(5, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, 10, true, false,
                p -> !((Player) p).isCreative() && !((Player) p).isSpectator()));
    }

    /** Walks toward the target, but only when no special attack is running. */
    private class ChaseGoal extends Goal {
        ChaseGoal() {
            setFlags(java.util.EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            LivingEntity t = getTarget();
            return t != null && t.isAlive() && ability == Ability.NONE && !recovering && transitionTicks <= 0;
        }

        @Override
        public boolean canContinueToUse() {
            return canUse();
        }

        @Override
        public void tick() {
            LivingEntity t = getTarget();
            if (t == null) return;
            getLookControl().setLookAt(t, 30.0F, 30.0F);
            if (tickCount % 10 == 0) getNavigation().moveTo(t, 1.0);
        }

        @Override
        public void stop() {
            getNavigation().stop();
        }
    }

    // ------------------------------------------------------------ phases

    public int getPhase() {
        return entityData.get(DATA_PHASE);
    }

    public boolean isRaging() {
        return entityData.get(DATA_RAGE);
    }

    private void setRage(boolean on) {
        entityData.set(DATA_RAGE, on);
        AttributeInstance speed = getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed == null) return;
        speed.removeModifier(RAGE_SPEED_ID);
        if (on) {
            speed.addTransientModifier(new AttributeModifier(RAGE_SPEED_ID, "rage", 0.30,
                    AttributeModifier.Operation.MULTIPLY_BASE));
        }
    }

    private void updatePhase() {
        float ratio = getHealth() / getMaxHealth();
        int target = ratio > 0.66F ? 1 : ratio > 0.33F ? 2 : 3;
        if (target > getPhase()) startPhase(target);
        if (ratio < 0.15F && !finalRageUsed) {
            finalRageUsed = true;
            rageTicks = 900;
            setRage(true);
        }
    }

    private void startPhase(int phase) {
        entityData.set(DATA_PHASE, phase);
        bossEvent.setName(Component.translatable("entity.primalearth.primordial_rex").append(" - ")
                .append(Component.translatable("boss.primalearth.phase" + phase)));
        bossEvent.setColor(phase == 1 ? BossEvent.BossBarColor.BLUE : phase == 2 ? BossEvent.BossBarColor.PURPLE
                : BossEvent.BossBarColor.RED);
        if (phase > 1) {
            transitionTicks = ROAR_TOTAL + 10;   // invulnerable while roaring into the next phase
            rageTicks = 600;
            setRage(true);
            endAbilityState();
            startAbility(Ability.ROAR);
            for (Player p : level().getEntitiesOfClass(Player.class, getBoundingBox().inflate(48))) {
                p.displayClientMessage(Component.translatable("boss.primalearth.phase" + phase + ".announce"), true);
            }
        }
    }

    // --------------------------------------------------------- main loop

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        bossEvent.setProgress(getHealth() / getMaxHealth());
        LivingEntity target = getTarget();
        setAggressive(target != null);
        updatePhase();

        if (rageTicks > 0 && --rageTicks == 0) setRage(false);
        if (transitionTicks > 0) transitionTicks--;
        if (globalCooldown > 0) globalCooldown--;
        if (biteCooldown > 0) biteCooldown--;
        if (biteDelay > 0 && --biteDelay == 0) doBite();
        if (isRaging() && tickCount % 10 == 0 && level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.ANGRY_VILLAGER, getX(), getY() + getBbHeight() * 0.8, getZ(), 2, 1.5, 1.5, 1.5, 0);
        }

        if (ability != Ability.NONE) {
            tickAbility();
            return;
        }
        if (target == null || !target.isAlive() || recovering) return;

        if (globalCooldown <= 0 && transitionTicks <= 0) {
            Ability next = chooseAbility(target);
            if (next != Ability.NONE) {
                startAbility(next);
                return;
            }
        }
        tryBite(target);
    }

    private Ability chooseAbility(LivingEntity target) {
        long now = level().getGameTime();
        double d = distanceTo(target);
        int phase = getPhase();
        int[] w = new int[Ability.values().length];
        if (d < 12) w[Ability.STOMP.ordinal()] = 4;
        if (playerBehind(14)) w[Ability.TAIL_SWEEP.ordinal()] = 8;
        if (d < 30) w[Ability.ROAR.ordinal()] = 1;
        if (phase >= 2 && d > 10 && d < 45) w[Ability.CHARGE.ordinal()] = 4;
        if (phase >= 3 && d > 8 && d < 40) w[Ability.ENERGY_BURST.ordinal()] = 4;
        int total = 0;
        for (Ability a : Ability.values()) {
            if (readyAt.getOrDefault(a, 0L) > now) w[a.ordinal()] = 0;
            total += w[a.ordinal()];
        }
        if (total == 0) return Ability.NONE;
        int roll = random.nextInt(total);
        for (Ability a : Ability.values()) {
            roll -= w[a.ordinal()];
            if (roll < 0) return a;
        }
        return Ability.NONE;
    }

    private boolean playerBehind(double range) {
        Vec3 fwd = Vec3.directionFromRotation(0F, yBodyRot);
        for (Player p : level().getEntitiesOfClass(Player.class, getBoundingBox().inflate(range, 6, range),
                q -> !q.isCreative() && !q.isSpectator())) {
            Vec3 to = p.position().subtract(position()).multiply(1, 0, 1);
            if (to.lengthSqr() > 1 && to.normalize().dot(fwd) < -0.25) return true;
        }
        return false;
    }

    // --------------------------------------------------------- abilities

    private void startAbility(Ability a) {
        ability = a;
        abilityTick = 0;
        recovering = false;
        hitThisAbility.clear();
        lockedDir = Vec3.ZERO;
        switch (a) {
            case STOMP -> { triggerAnim("action", "stomp"); warn(SoundEvents.RAVAGER_ROAR, 1.6F, 0.5F); }
            case TAIL_SWEEP -> { triggerAnim("action", "tail_sweep"); warn(SoundEvents.RAVAGER_ROAR, 1.6F, 0.7F); }
            case ROAR -> { triggerAnim("action", "roar"); warn(SoundEvents.ENDER_DRAGON_GROWL, 3.0F, 0.6F); }
            case CHARGE -> { triggerAnim("action", "charge"); warn(SoundEvents.RAVAGER_STUNNED, 2.0F, 0.5F); }
            case ENERGY_BURST -> { triggerAnim("action", "energy_burst"); warn(SoundEvents.BEACON_POWER_SELECT, 3.0F, 0.5F); }
            default -> { }
        }
    }

    private void warn(SoundEvent sound, float volume, float pitch) {
        level().playSound(null, blockPosition(), sound, SoundSource.HOSTILE, volume, pitch);
    }

    private void endAbility(int cooldownTicks) {
        readyAt.put(ability, level().getGameTime() + cooldownTicks);
        globalCooldown = (int) ((getPhase() == 1 ? 60 : getPhase() == 2 ? 42 : 30) * (isRaging() ? 0.6 : 1.0));
        endAbilityState();
    }

    private void endAbilityState() {
        ability = Ability.NONE;
        abilityTick = 0;
        recovering = false;
    }

    private void faceTarget() {
        LivingEntity t = getTarget();
        if (t != null) getLookControl().setLookAt(t, 40.0F, 40.0F);
    }

    private void tickAbility() {
        abilityTick++;
        getNavigation().stop();
        switch (ability) {
            case STOMP -> {
                faceTarget();
                if (abilityTick < STOMP_WINDUP) {
                    if (abilityTick % 2 == 0) ring(9.0, ParticleTypes.SMALL_FLAME, 28);
                } else if (abilityTick == STOMP_WINDUP) {
                    damageRing(9.0, 1.0F, 1.1, true);
                    ring(9.0, ParticleTypes.EXPLOSION, 14);
                    warn(SoundEvents.GENERIC_EXPLODE, 2.0F, 0.6F);
                    warn(SoundEvents.ANVIL_LAND, 2.0F, 0.4F);
                }
                if (abilityTick >= STOMP_TOTAL) endAbility(100);
            }
            case TAIL_SWEEP -> {
                if (abilityTick < TAIL_WINDUP) {
                    if (abilityTick % 2 == 0) rearArc(14.0, ParticleTypes.CLOUD);
                } else if (abilityTick == TAIL_WINDUP) {
                    damageRear(14.0, 0.9F, 1.4);
                    rearArc(14.0, ParticleTypes.CRIT);
                    warn(SoundEvents.PLAYER_ATTACK_SWEEP, 3.0F, 0.4F);
                }
                if (abilityTick >= TAIL_TOTAL) endAbility(120);
            }
            case ROAR -> {
                faceTarget();
                if (abilityTick == ROAR_WINDUP) {
                    damageRing(30.0, 0.0F, 1.6, false);
                    ring(10.0, ParticleTypes.SONIC_BOOM, 3);
                    for (Player p : level().getEntitiesOfClass(Player.class, getBoundingBox().inflate(30, 10, 30))) {
                        p.addEffect(new net.minecraft.world.effect.MobEffectInstance(
                                net.minecraft.world.effect.MobEffects.MOVEMENT_SLOWDOWN, 60, 0));
                    }
                }
                if (abilityTick >= ROAR_TOTAL) endAbility(400);
            }
            case CHARGE -> tickCharge();
            case ENERGY_BURST -> tickBurst();
            default -> endAbilityState();
        }
    }

    private void tickCharge() {
        if (abilityTick < CHARGE_WINDUP) {
            faceTarget();
            if (abilityTick % 3 == 0 && level() instanceof ServerLevel sl) {
                sl.sendParticles(ParticleTypes.POOF, getX(), getY() + 0.2, getZ(), 12, 2.5, 0.1, 2.5, 0.05);
            }
            if (abilityTick == CHARGE_WINDUP - 1) {
                LivingEntity t = getTarget();
                Vec3 to = t == null ? Vec3.directionFromRotation(0F, yBodyRot)
                        : t.position().subtract(position()).multiply(1, 0, 1).normalize();
                lockedDir = to;
            }
            return;
        }
        if (abilityTick < CHARGE_WINDUP + CHARGE_RUN && !recovering) {
            setYRot((float) (Math.toDegrees(Math.atan2(-lockedDir.x, lockedDir.z))));
            yBodyRot = getYRot();
            setDeltaMovement(lockedDir.x * 0.85, getDeltaMovement().y, lockedDir.z * 0.85);
            hitPlayersInFront(1.2F, 1.8);
            if (horizontalCollision && abilityTick > CHARGE_WINDUP + 4) {
                recovering = true;          // slammed into a wall: stunned, takes extra damage
                abilityTick = CHARGE_WINDUP + CHARGE_RUN;
                ring(6.0, ParticleTypes.EXPLOSION, 8);
                warn(SoundEvents.GENERIC_EXPLODE, 2.0F, 0.5F);
            }
            return;
        }
        recovering = true;
        if (abilityTick % 5 == 0 && level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.SMOKE, getX(), getY() + getBbHeight() * 0.5, getZ(), 6, 2.0, 2.0, 2.0, 0.01);
        }
        if (abilityTick >= CHARGE_TOTAL) endAbility(260);
    }

    private void tickBurst() {
        LivingEntity t = getTarget();
        Vec3 eye = getEyePosition();
        if (abilityTick < BURST_WINDUP) {
            faceTarget();
            if (t != null && abilityTick < BURST_WINDUP - 12) {
                lockedDir = t.getEyePosition().subtract(eye).normalize();      // tracks until 12 ticks before firing
            }
            if (abilityTick % 2 == 0) {
                beamParticles(eye, lockedDir, ParticleTypes.END_ROD, 3);
                if (level() instanceof ServerLevel sl) {
                    sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY() + getBbHeight() * 0.75, getZ(), 6, 2.5, 3.0, 2.5, 0.1);
                }
            }
        } else if (abilityTick == BURST_WINDUP) {
            warn(SoundEvents.WARDEN_SONIC_BOOM, 3.0F, 0.5F);
            beamParticles(eye, lockedDir, ParticleTypes.SOUL_FIRE_FLAME, 1);
            for (int i = 3; i < 42; i++) {
                Vec3 p = eye.add(lockedDir.scale(i));
                for (Player pl : level().getEntitiesOfClass(Player.class, new AABB(p, p).inflate(1.8))) {
                    if (hitThisAbility.add(pl.getId())) hurtPlayer(pl, 1.3F, 0.8);
                }
            }
        }
        if (abilityTick >= BURST_TOTAL) endAbility(300);
    }

    // ---------------------------------------------------------- damage

    private float baseDamage() {
        return (12.0F + random.nextFloat() * 8.0F) * PrimalConfig.COMMON.bossDamageMultiplier.get().floatValue()
                * (isRaging() ? 1.25F : 1.0F);
    }

    private void hurtPlayer(Player p, float mult, double knock) {
        if (mult > 0) p.hurt(damageSources().mobAttack(this), baseDamage() * mult);
        Vec3 away = p.position().subtract(position()).multiply(1, 0, 1);
        if (away.lengthSqr() > 1.0E-4) away = away.normalize();
        p.push(away.x * knock, 0.5, away.z * knock);
        p.hurtMarked = true;
    }

    private void damageRing(double radius, float mult, double knock, boolean groundOnly) {
        for (Player p : level().getEntitiesOfClass(Player.class, getBoundingBox().inflate(radius, 6, radius),
                q -> q.isAlive() && !q.isSpectator())) {
            double dx = p.getX() - getX(), dz = p.getZ() - getZ();
            if (dx * dx + dz * dz > radius * radius) continue;
            if (groundOnly && !(p.onGround() || p.getY() - getY() < 0.6)) continue;   // jump to dodge the stomp
            hurtPlayer(p, mult, knock);
        }
    }

    private void damageRear(double range, float mult, double knock) {
        Vec3 fwd = Vec3.directionFromRotation(0F, yBodyRot);
        for (Player p : level().getEntitiesOfClass(Player.class, getBoundingBox().inflate(range, 6, range),
                q -> q.isAlive() && !q.isSpectator())) {
            Vec3 to = p.position().subtract(position()).multiply(1, 0, 1);
            if (to.lengthSqr() > range * range || to.lengthSqr() < 1.0E-4) continue;
            if (to.normalize().dot(fwd) < -0.25) hurtPlayer(p, mult, knock);
        }
    }

    private void hitPlayersInFront(float mult, double knock) {
        for (Player p : level().getEntitiesOfClass(Player.class, getBoundingBox().inflate(2.5, 2, 2.5),
                q -> q.isAlive() && !q.isSpectator())) {
            if (hitThisAbility.add(p.getId())) hurtPlayer(p, mult, knock);
        }
    }

    private void tryBite(LivingEntity target) {
        double reach = getBbWidth() * 0.5 + target.getBbWidth() * 0.5 + 3.5;
        if (biteCooldown <= 0 && distanceToSqr(target) <= reach * reach) {
            biteCooldown = isRaging() ? 22 : 34;
            biteDelay = 8;
            triggerAnim("action", "attack");
            warn(SoundEvents.RAVAGER_ATTACK, 2.0F, 0.5F);
        }
    }

    private void doBite() {
        LivingEntity t = getTarget();
        if (t == null || !t.isAlive()) return;
        double reach = getBbWidth() * 0.5 + t.getBbWidth() * 0.5 + 4.5;
        if (distanceToSqr(t) > reach * reach) return;
        t.hurt(damageSources().mobAttack(this), baseDamage());
        Vec3 away = t.position().subtract(position()).multiply(1, 0, 1).normalize();
        t.push(away.x * 0.9, 0.35, away.z * 0.9);
        t.hurtMarked = true;
    }

    // -------------------------------------------------------- telegraphs

    private void ring(double radius, ParticleOptions type, int count) {
        if (!(level() instanceof ServerLevel sl)) return;
        for (int i = 0; i < count; i++) {
            double a = Math.PI * 2 * i / count;
            sl.sendParticles(type, getX() + Math.cos(a) * radius, getY() + 0.2, getZ() + Math.sin(a) * radius, 1, 0, 0.05, 0, 0);
        }
    }

    private void rearArc(double radius, ParticleOptions type) {
        if (!(level() instanceof ServerLevel sl)) return;
        double base = Math.toRadians(yBodyRot + 90.0) + Math.PI;   // direction behind the boss
        for (int i = -6; i <= 6; i++) {
            double a = base + i * 0.17;
            sl.sendParticles(type, getX() + Math.cos(a) * radius, getY() + 0.3, getZ() + Math.sin(a) * radius, 1, 0.1, 0.1, 0.1, 0);
        }
    }

    private void beamParticles(Vec3 from, Vec3 dir, ParticleOptions type, int step) {
        if (!(level() instanceof ServerLevel sl) || dir.lengthSqr() < 1.0E-4) return;
        for (int i = 3; i < 42; i += step) {
            Vec3 p = from.add(dir.scale(i));
            sl.sendParticles(type, p.x, p.y, p.z, 1, 0.05, 0.05, 0.05, 0);
        }
    }

    // ----------------------------------------------------------- combat

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (transitionTicks > 0 && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return false;
        if (recovering) amount *= 1.5F;
        return super.hurt(source, amount);
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public boolean canChangeDimensions() {
        return false;
    }

    // ------------------------------------------------------------- boss bar

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        bossEvent.removePlayer(player);
    }

    @Override
    public void remove(RemovalReason reason) {
        super.remove(reason);
        bossEvent.removeAllPlayers();
    }

    // ------------------------------------------------------------- sounds

    @Nullable
    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.RAVAGER_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.RAVAGER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENDER_DRAGON_DEATH;
    }

    @Override
    public float getVoicePitch() {
        return 0.4F;
    }

    @Override
    protected void playStepSound(BlockPos pos, net.minecraft.world.level.block.state.BlockState state) {
        playSound(SoundEvents.RAVAGER_STEP, 1.0F, 0.35F);
    }

    // ---------------------------------------------------------- save data

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(DATA_PHASE, 1);
        entityData.define(DATA_RAGE, false);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Phase", getPhase());
        tag.putInt("RageTicks", rageTicks);
        tag.putBoolean("FinalRage", finalRageUsed);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        int phase = Math.max(1, tag.getInt("Phase"));
        entityData.set(DATA_PHASE, phase);
        rageTicks = tag.getInt("RageTicks");
        finalRageUsed = tag.getBoolean("FinalRage");
        setRage(rageTicks > 0);
        bossEvent.setName(Component.translatable("entity.primalearth.primordial_rex").append(" - ")
                .append(Component.translatable("boss.primalearth.phase" + phase)));
        bossEvent.setColor(phase == 1 ? BossEvent.BossBarColor.BLUE : phase == 2 ? BossEvent.BossBarColor.PURPLE
                : BossEvent.BossBarColor.RED);
    }

    // ---------------------------------------------------------- animation

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        String p = "animation.primordial_rex.";
        controllers.add(new AnimationController<>(this, "move", 8, this::moveAnimation));
        controllers.add(new AnimationController<>(this, "action", 3, state -> PlayState.STOP)
                .triggerableAnim("attack", once(p + "attack"))
                .triggerableAnim("roar", once(p + "roar"))
                .triggerableAnim("stomp", once(p + "stomp"))
                .triggerableAnim("tail_sweep", once(p + "tail_sweep"))
                .triggerableAnim("charge", once(p + "charge"))
                .triggerableAnim("energy_burst", once(p + "energy_burst")));
    }

    private static RawAnimation once(String name) {
        return RawAnimation.begin().then(name, Animation.LoopType.PLAY_ONCE);
    }

    private PlayState moveAnimation(AnimationState<PrimordialRex> state) {
        String p = "animation.primordial_rex.";
        if (state.isMoving()) {
            boolean fast = state.getLimbSwingAmount() > 0.5F || isRaging();
            return state.setAndContinue(RawAnimation.begin().thenLoop(p + (fast ? "run" : "walk")));
        }
        return state.setAndContinue(RawAnimation.begin().thenLoop(p + "idle"));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }
}
