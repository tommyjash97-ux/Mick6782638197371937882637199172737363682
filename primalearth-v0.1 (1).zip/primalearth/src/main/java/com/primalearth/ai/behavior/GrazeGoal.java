package com.primalearth.ai.behavior;

import com.primalearth.ai.memory.DinoMemory;
import com.primalearth.entity.dinosaur.Dinosaur;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import java.util.EnumSet;

/** Herbivores look for plants when hungry, walk there, eat (and visibly change the terrain). */
public class GrazeGoal extends Goal {
    private static final int EAT_TICKS = 40;

    private final Dinosaur dino;
    private BlockPos target;
    private int cooldown;
    private int eatTimer;

    public GrazeGoal(Dinosaur dino) {
        this.dino = dino;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        if (dino.getHunger() > 80 || dino.getTarget() != null) return false;
        if (--cooldown > 0) return false;
        cooldown = dino.aiInterval() * 3 + dino.getRandom().nextInt(20);
        target = findFood();
        return target != null;
    }

    @Override
    public boolean canContinueToUse() {
        return target != null && isEdible(dino.level().getBlockState(target))
                && dino.getTarget() == null && dino.getHunger() < 95;
    }

    @Override
    public void start() {
        eatTimer = 0;
        moveToTarget();
    }

    @Override
    public void tick() {
        double dx = dino.getX() - (target.getX() + 0.5);
        double dz = dino.getZ() - (target.getZ() + 0.5);
        double reach = dino.getBbWidth() * 0.5 + 1.7;
        boolean closeEnough = dx * dx + dz * dz <= reach * reach && target.getY() - dino.getY() <= dino.getBbHeight();
        if (!closeEnough) {
            eatTimer = 0;
            if (dino.tickCount % 20 == 0) moveToTarget();
            return;
        }
        dino.getNavigation().stop();
        dino.getLookControl().setLookAt(target.getX() + 0.5, target.getY() + 0.5, target.getZ() + 0.5);
        if (eatTimer == 0) {
            eatTimer = EAT_TICKS;
            dino.triggerAnim("action", "eat");
        } else if (--eatTimer == 0) {
            consume();
            target = null;
        }
    }

    @Override
    public void stop() {
        target = null;
        eatTimer = 0;
        dino.getNavigation().stop();
    }

    private void moveToTarget() {
        BlockPos stand = dino.level().getBlockState(target).is(Blocks.GRASS_BLOCK) ? target.above() : target;
        dino.getNavigation().moveTo(stand.getX() + 0.5, stand.getY(), stand.getZ() + 0.5, 1.0);
    }

    private void consume() {
        Level level = dino.level();
        BlockState state = level.getBlockState(target);
        if (!isEdible(state)) return;
        if (level.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)) {
            level.levelEvent(2001, target, Block.getId(state));
            level.setBlock(target, state.is(Blocks.GRASS_BLOCK) ? Blocks.DIRT.defaultBlockState()
                    : Blocks.AIR.defaultBlockState(), Block.UPDATE_ALL);
        }
        dino.eat(state.is(BlockTags.LEAVES) ? 18F : 22F);
        dino.rememberFood(target);
    }

    private BlockPos findFood() {
        Level level = dino.level();
        RandomSource r = dino.getRandom();
        BlockPos origin = dino.blockPosition();
        long now = level.getGameTime();
        int up = Math.max(1, (int) dino.getBbHeight());
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        for (int i = 0; i < 24; i++) {
            BlockPos p = origin.offset(r.nextInt(17) - 8, r.nextInt(up + 3) - 2, r.nextInt(17) - 8);
            if (!isEdible(level.getBlockState(p))) continue;
            if (dino.memory().nearDanger(p, now, 10)) continue;
            double d = origin.distSqr(p);
            if (d < bestD) {
                bestD = d;
                best = p;
            }
        }
        if (best == null) {
            BlockPos remembered = dino.memory().nearest(DinoMemory.Kind.FOOD, origin, now, 24);
            if (remembered != null && !dino.memory().nearDanger(remembered, now, 10)) {
                best = remembered;
            }
        }
        return best;
    }

    private static boolean isEdible(BlockState s) {
        return s.is(Blocks.GRASS_BLOCK) || s.is(BlockTags.LEAVES) || s.is(Blocks.FERN)
                || s.is(Blocks.GRASS) || s.is(Blocks.TALL_GRASS) || s.is(Blocks.LARGE_FERN);
    }
}
