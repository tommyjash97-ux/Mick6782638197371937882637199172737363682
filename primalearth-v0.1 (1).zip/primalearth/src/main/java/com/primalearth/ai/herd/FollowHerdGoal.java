package com.primalearth.ai.herd;

import com.primalearth.entity.dinosaur.Dinosaur;
import net.minecraft.world.entity.ai.goal.Goal;

import java.util.EnumSet;
import java.util.List;

/**
 * Keeps herd animals (and raptor packs) together. The neighbour search runs only every
 * few ticks (see AI interval in the config), never every tick.
 */
public class FollowHerdGoal extends Goal {
    private final Dinosaur dino;
    private final double speed;
    private Dinosaur leader;
    private int cooldown;

    public FollowHerdGoal(Dinosaur dino, double speed) {
        this.dino = dino;
        this.speed = speed;
        setFlags(EnumSet.of(Flag.MOVE));
    }

    @Override
    public boolean canUse() {
        if (dino.getTarget() != null) return false;
        if (--cooldown > 0) return false;
        cooldown = dino.aiInterval() * 4 + dino.getRandom().nextInt(20);

        List<Dinosaur> mates = dino.level().getEntitiesOfClass(Dinosaur.class,
                dino.getBoundingBox().inflate(22, 8, 22),
                d -> d != dino && d.isAlive() && d.species() == dino.species());
        Dinosaur best = null;
        for (Dinosaur d : mates) {
            // follow the oldest nearby member: it acts as herd leader
            if (best == null || d.ageTicks() > best.ageTicks()) best = d;
        }
        if (best == null || best.ageTicks() < dino.ageTicks()) return false; // we lead: no need to follow
        double min = 5.0 + dino.getBbWidth();
        if (dino.distanceToSqr(best) < min * min) return false;
        leader = best;
        return true;
    }

    @Override
    public boolean canContinueToUse() {
        if (leader == null || !leader.isAlive() || dino.getTarget() != null) return false;
        double d = dino.distanceToSqr(leader);
        double min = 3.0 + dino.getBbWidth();
        return d > min * min && d < 48 * 48;
    }

    @Override
    public void start() {
        dino.getNavigation().moveTo(leader, speed);
    }

    @Override
    public void tick() {
        if (dino.tickCount % 20 == 0) dino.getNavigation().moveTo(leader, speed);
    }

    @Override
    public void stop() {
        leader = null;
        dino.getNavigation().stop();
    }
}
