package com.primalearth.ai.memory;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;

import java.util.ArrayList;
import java.util.List;

/** Tiny per-creature memory. Entries expire and the list is capped, so cost stays constant. */
public final class DinoMemory {
    public enum Kind { DANGER, FOOD }

    private record Entry(Kind kind, BlockPos pos, long expiry) {}

    private final List<Entry> entries = new ArrayList<>(8);

    public void remember(Kind kind, BlockPos pos, long now, int ttlTicks, int maxEntries) {
        entries.removeIf(e -> e.expiry() <= now || (e.kind() == kind && e.pos().distSqr(pos) < 16));
        entries.add(new Entry(kind, pos.immutable(), now + ttlTicks));
        while (entries.size() > Math.max(1, maxEntries)) entries.remove(0);
    }

    /** Nearest non-expired memory of this kind within maxDist, or null. */
    public BlockPos nearest(Kind kind, BlockPos from, long now, double maxDist) {
        BlockPos best = null;
        double bestD = maxDist * maxDist;
        for (Entry e : entries) {
            if (e.kind() != kind || e.expiry() <= now) continue;
            double d = e.pos().distSqr(from);
            if (d <= bestD) {
                bestD = d;
                best = e.pos();
            }
        }
        return best;
    }

    public boolean nearDanger(BlockPos pos, long now, double radius) {
        return nearest(Kind.DANGER, pos, now, radius) != null;
    }

    public ListTag save() {
        ListTag list = new ListTag();
        for (Entry e : entries) {
            CompoundTag t = new CompoundTag();
            t.putString("Kind", e.kind().name());
            t.putLong("Pos", e.pos().asLong());
            t.putLong("Expiry", e.expiry());
            list.add(t);
        }
        return list;
    }

    public void load(ListTag list) {
        entries.clear();
        for (int i = 0; i < list.size() && i < 16; i++) {
            CompoundTag t = list.getCompound(i);
            try {
                entries.add(new Entry(Kind.valueOf(t.getString("Kind")), BlockPos.of(t.getLong("Pos")), t.getLong("Expiry")));
            } catch (IllegalArgumentException ignored) {
                // unknown kind from a newer version: skip
            }
        }
    }

    public static final int LIST_TAG = Tag.TAG_COMPOUND;
}
