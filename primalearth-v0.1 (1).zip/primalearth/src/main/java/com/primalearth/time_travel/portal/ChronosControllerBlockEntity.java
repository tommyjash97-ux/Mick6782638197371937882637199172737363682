package com.primalearth.time_travel.portal;

import com.primalearth.config.PrimalConfig;
import com.primalearth.registry.ModBlockEntities;
import com.primalearth.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.List;

/** Stores installed components, energy and open timer. All logic runs on the server. */
public class ChronosControllerBlockEntity extends BlockEntity {
    public static final int ENERGY_PER_CRYSTAL = 2500;

    private int installedMask;
    private int energy;
    private int openTicks;
    private boolean openAxisX = true;

    public ChronosControllerBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.CHRONOS_CONTROLLER.get(), pos, state);
    }

    // ---------------------------------------------------------------- state

    public boolean isInstalled(GateComponent c) {
        return (installedMask & c.bit()) != 0;
    }

    public int installedCount() {
        return Integer.bitCount(installedMask);
    }

    private int requiredEnergy() {
        return PrimalConfig.COMMON.portalEnergyRequirement.get();
    }

    private int maxEnergy() {
        return requiredEnergy() * 2;
    }

    private Direction.Axis openAxis() {
        return openAxisX ? Direction.Axis.X : Direction.Axis.Z;
    }

    // ---------------------------------------------------------- interaction

    public InteractionResult interact(ServerPlayer player, ItemStack held) {
        GateComponent c = GateComponent.fromItem(held.getItem());
        if (c == null) {
            tryOpen(player);
            return InteractionResult.CONSUME;
        }

        if (!isInstalled(c)) {
            installedMask |= c.bit();
            if (c == GateComponent.QUANTUM_POWER_CELL) {
                energy = Math.max(energy, requiredEnergy());
            }
            consume(player, held);
            setChanged();
            player.displayClientMessage(Component.translatable("message.primalearth.gate.installed",
                    c.displayName(), installedCount(), GateComponent.values().length), false);
        } else if (c == GateComponent.TEMPORAL_CRYSTAL) {
            if (energy >= maxEnergy()) {
                player.displayClientMessage(Component.translatable("message.primalearth.gate.energy_full"), true);
            } else {
                energy = Math.min(maxEnergy(), energy + ENERGY_PER_CRYSTAL);
                consume(player, held);
                setChanged();
                player.displayClientMessage(Component.translatable("message.primalearth.gate.energy",
                        energy, maxEnergy()), true);
            }
        } else {
            player.displayClientMessage(Component.translatable("message.primalearth.gate.already_installed",
                    c.displayName()), true);
        }
        return InteractionResult.CONSUME;
    }

    private static void consume(ServerPlayer player, ItemStack held) {
        if (!player.getAbilities().instabuild) held.shrink(1);
    }

    public void tryOpen(ServerPlayer player) {
        Level level = this.level;
        if (level == null) return;
        BlockState state = getBlockState();

        if (state.getValue(ChronosControllerBlock.ACTIVE)) {
            sendStatus(player);
            return;
        }
        if (!PrimalConfig.COMMON.dimensionTravelEnabled.get()) {
            player.displayClientMessage(Component.translatable("message.primalearth.gate.travel_disabled"), true);
            return;
        }
        if (PrimalConfig.COMMON.portalActivationOpOnly.get() && !player.hasPermissions(2)) {
            player.displayClientMessage(Component.translatable("message.primalearth.gate.op_only"), true);
            return;
        }

        List<Component> missing = new ArrayList<>();
        for (GateComponent c : GateComponent.values()) {
            if (!isInstalled(c)) missing.add(c.displayName());
        }
        if (!missing.isEmpty()) {
            MutableComponent list = Component.empty();
            for (int i = 0; i < missing.size(); i++) {
                if (i > 0) list.append(", ");
                list.append(missing.get(i));
            }
            player.displayClientMessage(Component.translatable("message.primalearth.gate.missing", list), false);
            return;
        }

        Direction.Axis axis = ChronosGateStructure.findAxis(level, worldPosition);
        if (axis == null) {
            player.displayClientMessage(Component.translatable("message.primalearth.gate.structure_invalid"), false);
            return;
        }
        if (energy < requiredEnergy()) {
            player.displayClientMessage(Component.translatable("message.primalearth.gate.not_enough_energy",
                    energy, requiredEnergy()), false);
            return;
        }

        energy -= requiredEnergy();
        openAxisX = axis == Direction.Axis.X;
        openTicks = PrimalConfig.COMMON.portalOpenSeconds.get() * 20;
        BlockState portal = ModBlocks.CHRONOS_PORTAL.get().defaultBlockState().setValue(ChronosPortalBlock.AXIS, axis);
        for (BlockPos p : ChronosGateStructure.interior(worldPosition, axis)) {
            level.setBlock(p, portal, Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE);
        }
        level.setBlock(worldPosition, state.setValue(ChronosControllerBlock.ACTIVE, true), Block.UPDATE_ALL);
        level.playSound(null, worldPosition, SoundEvents.BEACON_ACTIVATE, SoundSource.BLOCKS, 1.5F, 0.6F);
        setChanged();
        player.displayClientMessage(Component.translatable("message.primalearth.gate.opened"), false);
    }

    private void sendStatus(ServerPlayer player) {
        player.displayClientMessage(Component.translatable("message.primalearth.gate.status",
                installedCount(), GateComponent.values().length, energy, requiredEnergy(), openTicks / 20), false);
    }

    // ----------------------------------------------------------- lifecycle

    public static void serverTick(Level level, BlockPos pos, BlockState state, ChronosControllerBlockEntity be) {
        if (be.openTicks <= 0) return;
        be.openTicks--;

        if (level instanceof ServerLevel sl && be.openTicks % 10 == 0) {
            int count = 4; // client config is not available on a dedicated server
            for (BlockPos p : ChronosGateStructure.interior(pos, be.openAxis())) {
                if (sl.random.nextInt(3) == 0) {
                    sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5,
                            count, 0.3, 0.3, 0.3, 0.02);
                }
            }
        }
        if (be.openTicks % 100 == 0) be.setChanged();
        if (be.openTicks == 0) be.close(level, pos, state);
    }

    private void close(Level level, BlockPos pos, BlockState state) {
        removePortalBlocks(level);
        if (state.getValue(ChronosControllerBlock.ACTIVE)) {
            level.setBlock(pos, state.setValue(ChronosControllerBlock.ACTIVE, false), Block.UPDATE_ALL);
        }
        level.playSound(null, pos, SoundEvents.BEACON_DEACTIVATE, SoundSource.BLOCKS, 1.5F, 0.6F);
        openTicks = 0;
        setChanged();
    }

    private void removePortalBlocks(Level level) {
        for (BlockPos p : ChronosGateStructure.interior(worldPosition, openAxis())) {
            if (level.getBlockState(p).is(ModBlocks.CHRONOS_PORTAL.get())) {
                level.setBlock(p, net.minecraft.world.level.block.Blocks.AIR.defaultBlockState(), Block.UPDATE_ALL);
            }
        }
    }

    /** Called when the controller is broken: closes the portal and returns installed components. */
    public void onBroken() {
        Level level = this.level;
        if (level == null || level.isClientSide) return;
        removePortalBlocks(level);
        for (GateComponent c : GateComponent.values()) {
            if (isInstalled(c)) {
                Containers.dropItemStack(level, worldPosition.getX() + 0.5, worldPosition.getY() + 0.5,
                        worldPosition.getZ() + 0.5, new ItemStack(c.item()));
            }
        }
        installedMask = 0;
    }

    // --------------------------------------------------------- persistence

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putInt("Installed", installedMask);
        tag.putInt("Energy", energy);
        tag.putInt("OpenTicks", openTicks);
        tag.putBoolean("AxisX", openAxisX);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        installedMask = tag.getInt("Installed");
        energy = tag.getInt("Energy");
        openTicks = tag.getInt("OpenTicks");
        openAxisX = !tag.contains("AxisX") || tag.getBoolean("AxisX");
    }
}
