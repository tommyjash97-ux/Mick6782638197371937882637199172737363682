package com.primalearth.time_travel.portal;

import com.primalearth.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.List;

/**
 * Multiblock layout: a vertical 5x5 ring of Chronos Frames with the Chronos Controller
 * as the bottom-centre block. The 3x3 interior becomes the portal.
 */
public final class ChronosGateStructure {
    private ChronosGateStructure() {}

    public static Direction along(Direction.Axis axis) {
        return axis == Direction.Axis.X ? Direction.EAST : Direction.SOUTH;
    }

    /** Bottom-left corner of the 5x5 ring. */
    public static BlockPos origin(BlockPos controller, Direction.Axis axis) {
        return controller.relative(along(axis), -2);
    }

    public static List<BlockPos> interior(BlockPos controller, Direction.Axis axis) {
        List<BlockPos> list = new ArrayList<>(9);
        BlockPos origin = origin(controller, axis);
        Direction d = along(axis);
        for (int i = 1; i <= 3; i++) {
            for (int j = 1; j <= 3; j++) {
                list.add(origin.relative(d, i).above(j));
            }
        }
        return list;
    }

    public static boolean isValid(Level level, BlockPos controller, Direction.Axis axis) {
        BlockPos origin = origin(controller, axis);
        Direction d = along(axis);
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                BlockPos p = origin.relative(d, i).above(j);
                BlockState s = level.getBlockState(p);
                boolean perimeter = i == 0 || i == 4 || j == 0 || j == 4;
                if (perimeter) {
                    if (!p.equals(controller) && !s.is(ModBlocks.CHRONOS_FRAME.get())) return false;
                } else if (!(s.isAir() || s.canBeReplaced() || s.is(ModBlocks.CHRONOS_PORTAL.get()))) {
                    return false;
                }
            }
        }
        return true;
    }

    /** Returns the axis (X or Z) of a valid gate around this controller, or null. */
    public static Direction.Axis findAxis(Level level, BlockPos controller) {
        if (isValid(level, controller, Direction.Axis.X)) return Direction.Axis.X;
        if (isValid(level, controller, Direction.Axis.Z)) return Direction.Axis.Z;
        return null;
    }
}
