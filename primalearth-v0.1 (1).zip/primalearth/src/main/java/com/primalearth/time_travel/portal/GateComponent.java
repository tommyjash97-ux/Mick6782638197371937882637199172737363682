package com.primalearth.time_travel.portal;

import com.primalearth.registry.ModItems;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;

import java.util.function.Supplier;

/** The 8 components a Chronos Gate needs before it can open. */
public enum GateComponent {
    CHRONOS_CORE(() -> ModItems.CHRONOS_CORE.get()),
    TEMPORAL_CRYSTAL(() -> ModItems.TEMPORAL_CRYSTAL.get()),
    ANCIENT_GEAR(() -> ModItems.ANCIENT_GEAR.get()),
    ENERGY_CONDUCTOR(() -> ModItems.ENERGY_CONDUCTOR.get()),
    TIME_STABILIZER(() -> ModItems.TIME_STABILIZER.get()),
    PORTAL_CONTROLLER(() -> ModItems.PORTAL_CONTROLLER.get()),
    ANCIENT_BLUEPRINT(() -> ModItems.ANCIENT_BLUEPRINT.get()),
    QUANTUM_POWER_CELL(() -> ModItems.QUANTUM_POWER_CELL.get());

    private final Supplier<Item> item;

    GateComponent(Supplier<Item> item) {
        this.item = item;
    }

    public Item item() {
        return item.get();
    }

    public int bit() {
        return 1 << ordinal();
    }

    public Component displayName() {
        return Component.translatable(item().getDescriptionId());
    }

    public static GateComponent fromItem(Item item) {
        for (GateComponent c : values()) {
            if (c.item() == item) return c;
        }
        return null;
    }
}
