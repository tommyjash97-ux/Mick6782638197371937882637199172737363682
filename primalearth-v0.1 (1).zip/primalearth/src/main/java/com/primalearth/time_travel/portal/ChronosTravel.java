package com.primalearth.time_travel.portal;

import com.primalearth.config.PrimalConfig;
import com.primalearth.data.PrimalWorldData;
import com.primalearth.dimension.PrimalDimensions;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.block.state.BlockState;
import com.primalearth.registry.ModBlocks;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Server-side travel between the Overworld (or any origin) and the Primal Dimension. */
public final class ChronosTravel {
    private static final int COOLDOWN_TICKS = 100;
    private static final Map<UUID, Integer> LAST_TRAVEL = new HashMap<>();

    private ChronosTravel() {}

    public static void tryTravel(ServerPlayer player, BlockPos portalPos, BlockState portalState) {
        MinecraftServer server = player.server;
        int now = server.getTickCount();
        Integer last = LAST_TRAVEL.get(player.getUUID());
        if (last != null && now - last < COOLDOWN_TICKS) return;

        if (!PrimalConfig.COMMON.dimensionTravelEnabled.get()) {
            player.displayClientMessage(Component.translatable("message.primalearth.gate.travel_disabled"), true);
            return;
        }
        LAST_TRAVEL.put(player.getUUID(), now);

        ServerLevel from = player.serverLevel();
        PrimalWorldData data = PrimalWorldData.get(server);

        if (from.dimension() == PrimalDimensions.PRIMAL_LEVEL) {
            travelBack(player, server, data);
        } else {
            travelToPrimal(player, server, data, from, portalPos, portalState);
        }
    }

    private static void travelToPrimal(ServerPlayer player, MinecraftServer server, PrimalWorldData data,
                                       ServerLevel from, BlockPos portalPos, BlockState portalState) {
        ServerLevel target = server.getLevel(PrimalDimensions.PRIMAL_LEVEL);
        if (target == null) {
            player.displayClientMessage(Component.translatable("message.primalearth.gate.no_dimension"), false);
            return;
        }

        BlockPos gate = data.getArrivalGate();
        if (gate == null || !target.getBlockState(gate).is(ModBlocks.CHRONOS_FRAME.get())) {
            gate = ChronosGateBuilder.buildArrivalGate(target);
            data.setArrivalGate(gate);
        }

        BlockPos exit = computeExit(from, portalPos, portalState);
        data.setReturn(player.getUUID(), new PrimalWorldData.ReturnPoint(
                from.dimension(), exit.getX() + 0.5, exit.getY(), exit.getZ() + 0.5, player.getYRot()));

        player.teleportTo(target, gate.getX() + 0.5, gate.getY() + 1, gate.getZ() + 3.5, 180.0F, 0.0F);
        target.playSound(null, player.blockPosition(), SoundEvents.PORTAL_TRAVEL, SoundSource.PLAYERS, 0.4F, 1.2F);
        player.displayClientMessage(Component.translatable("message.primalearth.gate.arrived"), true);
    }

    private static void travelBack(ServerPlayer player, MinecraftServer server, PrimalWorldData data) {
        PrimalWorldData.ReturnPoint rp = data.getReturn(player.getUUID());
        ServerLevel dest = rp != null ? server.getLevel(rp.dimension()) : null;
        if (rp != null && dest != null) {
            player.teleportTo(dest, rp.x(), rp.y(), rp.z(), rp.yRot(), 0.0F);
        } else {
            ServerLevel overworld = server.overworld();
            BlockPos spawn = overworld.getSharedSpawnPos();
            player.teleportTo(overworld, spawn.getX() + 0.5, spawn.getY(), spawn.getZ() + 0.5, 0.0F, 0.0F);
        }
        player.serverLevel().playSound(null, player.blockPosition(), SoundEvents.PORTAL_TRAVEL,
                SoundSource.PLAYERS, 0.4F, 1.2F);
        player.displayClientMessage(Component.translatable("message.primalearth.gate.returned"), true);
    }

    /** A spot two blocks in front of (or behind) the gate, so the player does not land inside the portal. */
    private static BlockPos computeExit(ServerLevel level, BlockPos portalPos, BlockState portalState) {
        Direction.Axis axis = portalState.getValue(ChronosPortalBlock.AXIS);
        BlockPos base = portalPos;
        while (level.getBlockState(base.below()).is(ModBlocks.CHRONOS_PORTAL.get())) base = base.below();
        Direction normal = axis == Direction.Axis.X ? Direction.SOUTH : Direction.EAST;
        for (Direction d : new Direction[]{normal, normal.getOpposite()}) {
            BlockPos c = base.relative(d, 2);
            if (level.getBlockState(c).getCollisionShape(level, c).isEmpty()
                    && level.getBlockState(c.above()).getCollisionShape(level, c.above()).isEmpty()) {
                return c;
            }
        }
        return base.relative(normal, 2);
    }
}
