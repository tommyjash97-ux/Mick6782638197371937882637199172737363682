package com.primalearth.time_travel.portal;

import com.primalearth.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.core.Direction;

/** Builds the always-open return gate on a small platform where players arrive in the Primal Dimension. */
public final class ChronosGateBuilder {
    private ChronosGateBuilder() {}

    /** Returns the bottom-centre frame block of the arrival gate, building it if needed. */
    public static BlockPos buildArrivalGate(ServerLevel level) {
        level.getChunk(0, 0);
        int surface = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, 0, 0);
        int y = Math.max(surface, level.getSeaLevel() + 2); // y = first walkable air level

        BlockState brick = Blocks.POLISHED_ANDESITE.defaultBlockState();
        BlockState air = Blocks.AIR.defaultBlockState();
        BlockState frame = ModBlocks.CHRONOS_FRAME.get().defaultBlockState();
        BlockState portal = ModBlocks.CHRONOS_PORTAL.get().defaultBlockState()
                .setValue(ChronosPortalBlock.AXIS, Direction.Axis.X);

        for (int dx = -4; dx <= 4; dx++) {
            for (int dz = -4; dz <= 4; dz++) {
                for (int dy = 0; dy <= 6; dy++) {
                    level.setBlock(new BlockPos(dx, y + dy, dz), air, Block.UPDATE_CLIENTS);
                }
                level.setBlock(new BlockPos(dx, y - 1, dz), brick, Block.UPDATE_CLIENTS);
                for (int py = y - 2; py > y - 42 && py > level.getMinBuildHeight(); py--) {
                    BlockPos pp = new BlockPos(dx, py, dz);
                    BlockState s = level.getBlockState(pp);
                    if (!s.isAir() && s.getFluidState().isEmpty() && !s.canBeReplaced()) break;
                    level.setBlock(pp, brick, Block.UPDATE_CLIENTS);
                }
            }
        }

        for (int i = -2; i <= 2; i++) {
            for (int j = 0; j <= 4; j++) {
                BlockPos p = new BlockPos(i, y - 1 + j, 0);
                boolean perimeter = Math.abs(i) == 2 || j == 0 || j == 4;
                if (perimeter) {
                    level.setBlock(p, frame, Block.UPDATE_CLIENTS);
                } else {
                    level.setBlock(p, portal, Block.UPDATE_CLIENTS | Block.UPDATE_KNOWN_SHAPE);
                }
            }
        }

        for (int sx = -4; sx <= 4; sx += 8) {
            for (int sz = -4; sz <= 4; sz += 8) {
                level.setBlock(new BlockPos(sx, y, sz), Blocks.LANTERN.defaultBlockState(), Block.UPDATE_CLIENTS);
            }
        }
        return new BlockPos(0, y - 1, 0);
    }
}
