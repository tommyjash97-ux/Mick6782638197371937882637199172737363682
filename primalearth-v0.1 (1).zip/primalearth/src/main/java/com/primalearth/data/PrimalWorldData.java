package com.primalearth.data;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.saveddata.SavedData;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** World-persistent mod data: per-player return points and the Primal Dimension arrival gate. */
public class PrimalWorldData extends SavedData {
    private static final String NAME = "primalearth_world";

    public record ReturnPoint(ResourceKey<Level> dimension, double x, double y, double z, float yRot) {}

    private final Map<UUID, ReturnPoint> returnPoints = new HashMap<>();
    @Nullable
    private BlockPos arrivalGate;

    public static PrimalWorldData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(PrimalWorldData::load, PrimalWorldData::new, NAME);
    }

    public void setReturn(UUID player, ReturnPoint point) {
        returnPoints.put(player, point);
        setDirty();
    }

    @Nullable
    public ReturnPoint getReturn(UUID player) {
        return returnPoints.get(player);
    }

    @Nullable
    public BlockPos getArrivalGate() {
        return arrivalGate;
    }

    public void setArrivalGate(BlockPos pos) {
        this.arrivalGate = pos;
        setDirty();
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        returnPoints.forEach((id, p) -> {
            CompoundTag t = new CompoundTag();
            t.putUUID("Id", id);
            t.putString("Dim", p.dimension().location().toString());
            t.putDouble("X", p.x());
            t.putDouble("Y", p.y());
            t.putDouble("Z", p.z());
            t.putFloat("Rot", p.yRot());
            list.add(t);
        });
        tag.put("ReturnPoints", list);
        if (arrivalGate != null) tag.putLong("ArrivalGate", arrivalGate.asLong());
        return tag;
    }

    public static PrimalWorldData load(CompoundTag tag) {
        PrimalWorldData data = new PrimalWorldData();
        ListTag list = tag.getList("ReturnPoints", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag t = list.getCompound(i);
            ResourceKey<Level> dim = ResourceKey.create(Registries.DIMENSION, new ResourceLocation(t.getString("Dim")));
            data.returnPoints.put(t.getUUID("Id"),
                    new ReturnPoint(dim, t.getDouble("X"), t.getDouble("Y"), t.getDouble("Z"), t.getFloat("Rot")));
        }
        if (tag.contains("ArrivalGate")) data.arrivalGate = BlockPos.of(tag.getLong("ArrivalGate"));
        return data;
    }
}
