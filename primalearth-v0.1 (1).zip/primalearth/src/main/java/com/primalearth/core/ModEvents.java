package com.primalearth.core;

import com.primalearth.PrimalEarth;
import com.primalearth.entity.dinosaur.Dinosaur;
import com.primalearth.registry.ModEntities;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.SpawnPlacementRegisterEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Mod-bus events shared by client and server. */
@Mod.EventBusSubscriber(modid = PrimalEarth.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ModEvents {
    private ModEvents() {}

    @SubscribeEvent
    public static void attributes(EntityAttributeCreationEvent event) {
        ModEntities.DINOSAURS.forEach((species, type) ->
                event.put(type.get(), Dinosaur.createAttributes(species).build()));
        event.put(ModEntities.PRIMORDIAL_REX.get(), com.primalearth.entity.kaiju.PrimordialRex.createAttributes().build());
    }

    @SubscribeEvent
    public static void spawnPlacements(SpawnPlacementRegisterEvent event) {
        ModEntities.DINOSAURS.values().forEach(type -> event.register(type.get(),
                SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                Dinosaur::checkSpawn, SpawnPlacementRegisterEvent.Operation.REPLACE));
    }
}
