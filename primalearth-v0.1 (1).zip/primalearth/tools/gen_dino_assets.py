#!/usr/bin/env python3
"""
Procedural block-model generator for Primal Earth creatures.

Writes, for every species:
  assets/primalearth/geo/entity/<id>.geo.json            (GeckoLib / Bedrock geometry)
  assets/primalearth/animations/entity/<id>.animation.json
  assets/primalearth/textures/entity/<id>.png
plus the dinosaur egg (model, animation, one texture per species).

These are starter models: each species has its own proportions, bone layout and
features (frill, sail, long neck...), painted procedurally. Replace them with
hand-made Blockbench art whenever you like: keep the bone names and the files
are drop-in replacements.

Units: 1 px = 1/16 block. Forward is -Z, up is +Y.
Usage: python3 tools/gen_dino_assets.py
"""
import json, math, os, random, struct, zlib

HERE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.normpath(os.path.join(HERE, '..', 'src', 'main', 'resources', 'assets', 'primalearth'))


# ------------------------------------------------------------------ helpers
def cube(origin, size, kind='skin'):
    return (tuple(origin), tuple(size), kind)


def mirror(cubes):
    """Mirror cubes across the X axis (left leg -> right leg)."""
    return [((-(o[0] + s[0]), o[1], o[2]), s, k) for (o, s, k) in cubes]


def bone(name, parent, pivot, cubes=()):
    return {'name': name, 'parent': parent, 'pivot': list(pivot), 'cubes': list(cubes)}


def clamp(v):
    return max(0, min(255, int(v)))


def shade(c, f):
    return tuple(clamp(x * f) for x in c)


def mix(a, b, t):
    t = max(0.0, min(1.0, t))
    return tuple(clamp(a[i] + (b[i] - a[i]) * t) for i in range(3))


def smooth(a, b, t):
    t = max(0.0, min(1.0, (t - a) / (b - a)))
    return t * t * (3 - 2 * t)


def hnoise(x, y, seed):
    n = (x * 374761393 + y * 668265263 + seed * 2147483647) & 0xFFFFFFFF
    n = (n ^ (n >> 13)) * 1274126177 & 0xFFFFFFFF
    return ((n ^ (n >> 16)) & 0xFFFF) / 65535.0


# ------------------------------------------------------------------ painting
def face_color(face, fx, fy, fw, fh, kind, pal, seed, gx, gy):
    n = (hnoise(gx, gy, seed) - 0.5) * 16
    blot = hnoise(gx // 3, gy // 3, seed + 5)
    if kind == 'horn':
        base = mix(pal['horn'], shade(pal['horn'], 0.65), fy / max(1, fh - 1))
    elif kind == 'claw':
        base = pal['claw']
    elif kind == 'crystal':
        base = mix((24, 120, 210), (170, 245, 255), 0.25 + 0.75 * blot)
    elif kind in ('frill', 'sail'):
        base = pal['accent']
        if (gx // 2) % 3 == 0:
            base = shade(base, 0.72)
    else:
        if face == 'top':
            base = pal['dorsal']
        elif face == 'bottom':
            base = pal['belly']
        else:
            t = fy / max(1, fh - 1)
            base = mix(pal['dorsal'], pal['belly'], smooth(0.5, 0.95, t))
            if pal.get('stripe') and t < 0.7 and (gx // 2) % 4 == 0:
                base = shade(base, 0.68)
        if blot < 0.18:
            base = shade(base, 0.86)
    return tuple(clamp(base[i] + n) for i in range(3))


def paint_cube(px, u, v, size, kind, pal, seed, glow=None):
    w, h, d = [int(math.ceil(s)) for s in size]
    faces = {
        'top': (u + d, v, w, d), 'bottom': (u + d + w, v, w, d),
        'right': (u, v + d, d, h), 'front': (u + d, v + d, w, h),
        'left': (u + d + w, v + d, d, h), 'back': (u + 2 * d + w, v + d, w, h),
    }
    for face, (x0, y0, fw, fh) in faces.items():
        for yy in range(fh):
            for xx in range(fw):
                gx, gy = x0 + xx, y0 + yy
                if 0 <= gx < len(px[0]) and 0 <= gy < len(px):
                    px[gy][gx] = face_color(face, xx, yy, fw, fh, kind, pal, seed, gx, gy) + (255,)
                    if glow is not None and kind == 'crystal':
                        glow[gy][gx] = px[gy][gx]
    # eyes on heads (the front edge of each side face is next to the 'front' face)
    if kind == 'head' and d >= 6 and h >= 5:
        for (ex, ey) in ((u + d - 4, v + d + 2), (u + d + w + 2, v + d + 2)):
            for dx in range(2):
                for dy in range(2):
                    px[ey + dy][ex + dx] = pal['eye'] + (255,)
                    if glow is not None and pal.get('eye_glow'):
                        glow[ey + dy][ex + dx] = pal['eye'] + (255,)
            px[ey + 1][ex + (1 if ex < u + d else 0)] = (15, 10, 5, 255)
    # teeth along the upper edge of jaws
    if kind == 'jaw' and d >= 8:
        for (x0, y0) in ((u, v + d), (u + d + w, v + d)):
            for xx in range(0, d, 2):
                px[y0][x0 + xx] = (235, 230, 215, 255)


def pack(cubes_all, tex):
    placements, x, y, rowh = [], 0, 0, 0
    for (_, size, _) in cubes_all:
        w, h, d = [int(math.ceil(s)) for s in size]
        fw, fh = 2 * d + 2 * w, d + h
        if x + fw > tex:
            x, y, rowh = 0, y + rowh, 0
        placements.append((x, y))
        x, rowh = x + fw, max(rowh, fh)
    if y + rowh > tex:
        return None
    return placements


def write_png(path, px):
    h, w = len(px), len(px[0])
    raw = b''.join(b'\x00' + b''.join(bytes(px[y][x]) for x in range(w)) for y in range(h))

    def chunk(t, d):
        c = struct.pack('>I', len(d)) + t + d
        return c + struct.pack('>I', zlib.crc32(t + d) & 0xffffffff)

    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'wb') as f:
        f.write(b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 6, 0, 0, 0))
                + chunk(b'IDAT', zlib.compress(raw)) + chunk(b'IEND', b''))


def write_json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w') as f:
        json.dump(obj, f, indent=1)


def build_model(ident, bones, pal, seed, texture_path=None):
    cubes_all = [c for b in bones for c in b['cubes']]
    tex = None
    for t in (64, 128, 256, 512):
        placements = pack(cubes_all, t)
        if placements:
            tex = t
            break
    assert tex, ident
    px = [[(0, 0, 0, 0)] * tex for _ in range(tex)]
    glow = [[(0, 0, 0, 0)] * tex for _ in range(tex)]
    idx = 0
    geo_bones = []
    for b in bones:
        gb = {'name': b['name'], 'pivot': b['pivot']}
        if b['parent']:
            gb['parent'] = b['parent']
        gcubes = []
        for (o, s, k) in b['cubes']:
            u, v = placements[idx]
            idx += 1
            paint_cube(px, u, v, s, k, pal, seed + idx, glow)
            gcubes.append({'origin': list(o), 'size': list(s), 'uv': [u, v]})
        if gcubes:
            gb['cubes'] = gcubes
        geo_bones.append(gb)
    geo = {'format_version': '1.12.0', 'minecraft:geometry': [{
        'description': {'identifier': 'geometry.' + ident, 'texture_width': tex, 'texture_height': tex,
                        'visible_bounds_width': 8, 'visible_bounds_height': 9, 'visible_bounds_offset': [0, 3, 0]},
        'bones': geo_bones}]}
    return geo, px, glow


# ------------------------------------------------------------------ animations
def kf(times, values):
    return {('%.2f' % t): v for t, v in zip(times, values)}


def anim_set(ident, bones, kind, p):
    names = {b['name'] for b in bones}
    A = {}

    def add(name, length, loop, channels):
        out = {}
        for bname, chans in channels.items():
            if bname in names:
                out[bname] = chans
        A[f'animation.{ident}.{name}'] = {'loop': loop, 'animation_length': length, 'bones': out}

    tails = [n for n in ('tail1', 'tail2', 'tail3', 'tail4') if n in names]
    necks = [n for n in ('neck', 'neck1', 'neck2', 'neck3', 'neck4') if n in names]

    # idle: slow breathing, tail drift
    ch = {'body': {'position': kf([0, 2, 4], [[0, 0, 0], [0, 0.4, 0], [0, 0, 0]])},
          'head': {'rotation': kf([0, 2, 4], [[0, 0, 0], [2, 1, 0], [0, 0, 0]])}}
    for i, t in enumerate(tails):
        a = 2 + i
        ch[t] = {'rotation': kf([0, 2, 4], [[0, -a, 0], [0, a, 0], [0, -a, 0]])}
    for i, n in enumerate(necks):
        ch[n] = {'rotation': kf([0, 2, 4], [[0, 0, 0], [1.2, 0, 0], [0, 0, 0]])}
    add('idle', 4.0, True, ch)

    def gait(length, amp, bob, sway, tilt):
        c = {}
        t5 = [0, length * .25, length * .5, length * .75, length]
        if kind == 'biped':
            c['leg_l'] = {'rotation': kf(t5, [[amp, 0, 0], [0, 0, 0], [-amp, 0, 0], [0, 0, 0], [amp, 0, 0]])}
            c['leg_r'] = {'rotation': kf(t5, [[-amp, 0, 0], [0, 0, 0], [amp, 0, 0], [0, 0, 0], [-amp, 0, 0]])}
            c['arm_l'] = {'rotation': kf(t5, [[-amp * .4, 0, 0], [0, 0, 0], [amp * .4, 0, 0], [0, 0, 0], [-amp * .4, 0, 0]])}
            c['arm_r'] = {'rotation': kf(t5, [[amp * .4, 0, 0], [0, 0, 0], [-amp * .4, 0, 0], [0, 0, 0], [amp * .4, 0, 0]])}
        else:
            c['leg_fl'] = {'rotation': kf(t5, [[amp, 0, 0], [0, 0, 0], [-amp, 0, 0], [0, 0, 0], [amp, 0, 0]])}
            c['leg_br'] = {'rotation': kf(t5, [[amp, 0, 0], [0, 0, 0], [-amp, 0, 0], [0, 0, 0], [amp, 0, 0]])}
            c['leg_fr'] = {'rotation': kf(t5, [[-amp, 0, 0], [0, 0, 0], [amp, 0, 0], [0, 0, 0], [-amp, 0, 0]])}
            c['leg_bl'] = {'rotation': kf(t5, [[-amp, 0, 0], [0, 0, 0], [amp, 0, 0], [0, 0, 0], [-amp, 0, 0]])}
        c['body'] = {'position': kf(t5, [[0, 0, 0], [0, bob, 0], [0, 0, 0], [0, bob, 0], [0, 0, 0]]),
                     'rotation': kf([0, length], [[tilt, 0, 0], [tilt, 0, 0]])}
        for i, t in enumerate(tails):
            s = sway * (1 + .4 * i)
            c[t] = {'rotation': kf(t5, [[0, s, 0], [0, 0, 0], [0, -s, 0], [0, 0, 0], [0, s, 0]])}
        c['head'] = {'rotation': kf(t5, [[1.5, 0, 0], [-1.5, 0, 0], [1.5, 0, 0], [-1.5, 0, 0], [1.5, 0, 0]])}
        for i, n in enumerate(necks):
            c[n] = {'rotation': kf(t5, [[0, sway * .3, 0], [0, 0, 0], [0, -sway * .3, 0], [0, 0, 0], [0, sway * .3, 0]])}
        return c

    add('walk', 1.2, True, gait(1.2, p['walk_amp'], p['bob'], 6, 0))
    add('run', 0.7, True, gait(0.7, p['run_amp'], p['bob'] * 1.6, 9, 4))

    # attack: wind up, lunge, snap
    add('attack', 0.9, False, {
        'head': {'position': kf([0, .25, .4, .9], [[0, 0, 0], [0, 1, 4], [0, -1, -8], [0, 0, 0]]),
                 'rotation': kf([0, .25, .4, .9], [[0, 0, 0], [-8, 0, 0], [14, 0, 0], [0, 0, 0]])},
        'jaw': {'rotation': kf([0, .25, .4, .55, .9], [[0, 0, 0], [0, 0, 0], [40, 0, 0], [0, 0, 0], [0, 0, 0]])},
        'body': {'rotation': kf([0, .25, .4, .9], [[0, 0, 0], [-3, 0, 0], [6, 0, 0], [0, 0, 0]])},
    })
    neck_dip = {n: {'rotation': kf([0, .5, 1, 1.5, 2], [[0, 0, 0], [18, 0, 0], [12, 0, 0], [18, 0, 0], [0, 0, 0]])} for n in necks}
    eat = {'head': {'rotation': kf([0, .5, 1, 1.5, 2], [[0, 0, 0], [35, 0, 0], [20, 0, 0], [35, 0, 0], [0, 0, 0]])}}
    eat.update(neck_dip)
    add('eat', 2.0, True, eat)
    add('roar', 2.5, False, {
        'head': {'rotation': kf([0, .4, 1.8, 2.5], [[0, 0, 0], [-25, 0, 0], [-25, 0, 0], [0, 0, 0]])},
        'jaw': {'rotation': kf([0, .4, .7, 1.8, 2.5], [[0, 0, 0], [0, 0, 0], [40, 0, 0], [40, 0, 0], [0, 0, 0]])},
        'body': {'rotation': kf([0, .4, 1.8, 2.5], [[0, 0, 0], [-4, 0, 0], [-4, 0, 0], [0, 0, 0]])},
        **{t: {'rotation': kf([0, .6, 1.2, 1.8, 2.5], [[0, 0, 0], [0, 6, 0], [0, -6, 0], [0, 6, 0], [0, 0, 0]])} for t in tails},
    })
    return {'format_version': '1.8.0', 'animations': A}


# ------------------------------------------------------------------ species
def theropod_legs(hip_pivot, thigh, shin, foot, claws, x_off=0):
    left = [cube(*thigh), cube(*shin), cube(*foot, 'skin')] + [cube(o, s, 'claw') for (o, s) in claws]
    return left


def species_trex():
    leg = [cube((2, 30, -4), (9, 24, 12)), cube((3, 3, -1), (6, 29, 7)), cube((2.5, 0, -9), (8, 4, 14)),
           cube((3, 0, -12), (2, 3, 3), 'claw'), cube((6, 0, -12), (2, 3, 3), 'claw'), cube((9, 0, -12), (2, 3, 3), 'claw')]
    arm = [cube((6.5, 43, -20), (3, 7, 3)), cube((6.5, 42, -23), (3, 2, 3), 'claw')]
    bones = [
        bone('root', None, (0, 0, 0)),
        bone('body', 'root', (0, 50, 0), [cube((-7, 40, -14), (14, 18, 26)), cube((-6.5, 42, -20), (13, 16, 7))]),
        bone('neck', 'body', (0, 54, -18), [cube((-5, 52, -26), (10, 12, 10))]),
        bone('head', 'neck', (0, 60, -26), [cube((-6, 56, -46), (12, 14, 20), 'head'), cube((-5, 57, -54), (10, 8, 8), 'head'),
                                            cube((-6.5, 70, -40), (3, 2, 6), 'horn'), cube((3.5, 70, -40), (3, 2, 6), 'horn')]),
        bone('jaw', 'head', (0, 58, -28), [cube((-5, 53, -52), (10, 4, 24), 'jaw')]),
        bone('tail1', 'body', (0, 50, 12), [cube((-5, 43, 12), (10, 13, 14))]),
        bone('tail2', 'tail1', (0, 49, 26), [cube((-4, 44, 26), (8, 10, 14))]),
        bone('tail3', 'tail2', (0, 48, 40), [cube((-2.5, 44, 40), (5, 6, 14))]),
        bone('arm_l', 'body', (6, 50, -16), arm),
        bone('arm_r', 'body', (-6, 50, -16), mirror(arm)),
        bone('leg_l', 'root', (6, 50, 2), leg),
        bone('leg_r', 'root', (-6, 50, 2), mirror(leg)),
    ]
    pal = dict(dorsal=(96, 90, 62), belly=(176, 160, 122), stripe=True, horn=(205, 190, 150), claw=(40, 36, 30), eye=(230, 170, 30))
    return bones, pal, 'biped', dict(walk_amp=26, run_amp=38, bob=0.8)


def species_spinosaurus():
    leg = [cube((1, 26, -5), (8, 20, 11)), cube((2, 2, -2), (6, 26, 6)), cube((1, 0, -8), (8, 3, 12)),
           cube((2, 0, -10), (2, 3, 2), 'claw'), cube((5, 0, -10), (2, 3, 2), 'claw')]
    arm = [cube((7, 34, -16), (3, 12, 3)), cube((7, 33, -20), (3, 2, 5), 'claw')]
    sail = [cube((-1, 50, z), (2, h, 4), 'sail') for z, h in ((-12, 8), (-8, 14), (-4, 20), (0, 22), (4, 20), (8, 14), (12, 8))]
    bones = [
        bone('root', None, (0, 0, 0)),
        bone('body', 'root', (0, 44, 0), [cube((-7, 34, -14), (14, 16, 28))]),
        bone('sail', 'body', (0, 50, 0), sail),
        bone('neck', 'body', (0, 48, -14), [cube((-4, 46, -22), (8, 12, 9))]),
        bone('head', 'neck', (0, 54, -22), [cube((-4, 50, -34), (8, 9, 12), 'head'), cube((-3, 50, -52), (6, 5, 18), 'head'),
                                            cube((-3.5, 50, -55), (7, 6, 3), 'head'), cube((-1, 59, -32), (2, 3, 6), 'sail')]),
        bone('jaw', 'head', (0, 52, -30), [cube((-2.5, 48, -52), (5, 3, 24), 'jaw')]),
        bone('tail1', 'body', (0, 42, 14), [cube((-5, 36, 14), (10, 12, 16))]),
        bone('tail2', 'tail1', (0, 42, 30), [cube((-4, 37, 30), (8, 11, 16)), cube((-1, 48, 30), (2, 8, 16), 'sail')]),
        bone('tail3', 'tail2', (0, 42, 46), [cube((-3, 38, 46), (6, 9, 14)), cube((-1, 47, 46), (2, 8, 14), 'sail')]),
        bone('arm_l', 'body', (7, 46, -12), arm),
        bone('arm_r', 'body', (-7, 46, -12), mirror(arm)),
        bone('leg_l', 'root', (6, 44, 2), leg),
        bone('leg_r', 'root', (-6, 44, 2), mirror(leg)),
    ]
    pal = dict(dorsal=(62, 92, 98), belly=(192, 186, 160), stripe=True, accent=(168, 66, 52), horn=(220, 210, 180), claw=(35, 35, 35), eye=(240, 200, 40))
    return bones, pal, 'biped', dict(walk_amp=22, run_amp=32, bob=0.7)


def species_velociraptor():
    leg = [cube((1, 12, -1), (4, 12, 6)), cube((1.5, 1, 0), (3, 13, 3)), cube((1, 0, -5), (4, 2, 8)),
           cube((2, 1, -7), (1, 3, 3), 'claw')]
    arm = [cube((3, 18, -10), (2, 2, 8)), cube((3, 17, -12), (2, 1, 3), 'claw')]
    bones = [
        bone('root', None, (0, 0, 0)),
        bone('body', 'root', (0, 22, 0), [cube((-3, 18, -8), (6, 9, 16))]),
        bone('neck', 'body', (0, 25, -8), [cube((-2, 24, -14), (4, 8, 7))]),
        bone('head', 'neck', (0, 30, -12), [cube((-3, 29, -24), (6, 6, 10), 'head'), cube((-2, 29, -30), (4, 4, 6), 'head')]),
        bone('jaw', 'head', (0, 29, -16), [cube((-2, 27, -29), (4, 2, 15), 'jaw')]),
        bone('tail1', 'body', (0, 22, 8), [cube((-2, 18, 8), (4, 6, 14))]),
        bone('tail2', 'tail1', (0, 21, 22), [cube((-1.5, 19, 22), (3, 4, 14))]),
        bone('tail3', 'tail2', (0, 21, 36), [cube((-1, 20, 36), (2, 3, 12))]),
        bone('arm_l', 'body', (3, 24, -6), arm),
        bone('arm_r', 'body', (-3, 24, -6), mirror(arm)),
        bone('leg_l', 'root', (3, 22, 2), leg),
        bone('leg_r', 'root', (-3, 22, 2), mirror(leg)),
    ]
    pal = dict(dorsal=(126, 74, 42), belly=(214, 192, 152), stripe=True, horn=(220, 205, 170), claw=(30, 25, 22), eye=(250, 210, 40))
    return bones, pal, 'biped', dict(walk_amp=34, run_amp=48, bob=0.5)


def species_triceratops():
    legf = [cube((0, 0, -2), (7, 22, 7)), cube((-0.5, 0, -2.5), (8, 3, 8))]
    legb = [cube((0, 0, -3), (7, 22, 7)), cube((-0.5, 0, -3.5), (8, 3, 8))]

    def at(cubes, x, z):
        return [((o[0] + x, o[1], o[2] + z), s, k) for (o, s, k) in cubes]

    frill_bumps = [cube((x, 50, -26), (3, 3, 3), 'horn') for x in (-12, -7, -2, 3, 8)]
    bones = [
        bone('root', None, (0, 0, 0)),
        bone('body', 'root', (0, 30, 2), [cube((-11, 18, -18), (22, 22, 40))]),
        bone('neck', 'body', (0, 34, -18), [cube((-6, 26, -26), (12, 14, 10))]),
        bone('head', 'neck', (0, 32, -26), [cube((-6, 26, -40), (12, 14, 14), 'head'), cube((-3, 26, -46), (6, 8, 6), 'head'),
                                            cube((-1, 34, -45), (2, 7, 2), 'horn'),
                                            cube((4, 38, -52), (2, 2, 15), 'horn'), cube((-6, 38, -52), (2, 2, 15), 'horn'),
                                            cube((-14, 30, -26), (28, 20, 3), 'frill')] + frill_bumps),
        bone('jaw', 'head', (0, 28, -30), [cube((-3, 24, -44), (6, 3, 12), 'jaw')]),
        bone('tail1', 'body', (0, 32, 22), [cube((-5, 26, 22), (10, 12, 14))]),
        bone('tail2', 'tail1', (0, 31, 36), [cube((-3, 27, 36), (6, 8, 14))]),
        bone('leg_fl', 'root', (8, 22, -12), at(legf, 5, -14)),
        bone('leg_fr', 'root', (-8, 22, -12), at(legf, -12, -14)),
        bone('leg_bl', 'root', (8, 22, 14), at(legb, 5, 12)),
        bone('leg_br', 'root', (-8, 22, 14), at(legb, -12, 12)),
    ]
    pal = dict(dorsal=(112, 106, 94), belly=(164, 152, 130), stripe=False, accent=(160, 76, 62), horn=(228, 218, 186), claw=(50, 45, 40), eye=(200, 140, 40))
    return bones, pal, 'quad', dict(walk_amp=22, run_amp=30, bob=0.5)


def species_brachiosaurus():
    legf = [cube((0, 0, 0), (10, 44, 10)), cube((-0.5, 0, -0.5), (11, 4, 11))]
    legb = [cube((0, 0, 0), (10, 42, 10)), cube((-0.5, 0, -0.5), (11, 4, 11))]

    def at(cubes, x, z):
        return [((o[0] + x, o[1], o[2] + z), s, k) for (o, s, k) in cubes]

    bones = [
        bone('root', None, (0, 0, 0)),
        bone('body', 'root', (0, 54, 2), [cube((-14, 40, -20), (28, 28, 44))]),
        bone('neck1', 'body', (0, 64, -18), [cube((-5, 62, -30), (10, 16, 12))]),
        bone('neck2', 'neck1', (0, 76, -28), [cube((-4.5, 74, -38), (9, 16, 10))]),
        bone('neck3', 'neck2', (0, 88, -36), [cube((-4, 86, -45), (8, 16, 10))]),
        bone('neck4', 'neck3', (0, 100, -43), [cube((-3.5, 98, -52), (7, 16, 9))]),
        bone('head', 'neck4', (0, 112, -50), [cube((-3.5, 108, -62), (7, 8, 12), 'head'), cube((-3, 108, -66), (6, 6, 5), 'head'),
                                              cube((-2, 116, -58), (4, 3, 6), 'horn')]),
        bone('jaw', 'head', (0, 110, -54), [cube((-3, 106, -64), (6, 2, 10), 'jaw')]),
        bone('tail1', 'body', (0, 58, 24), [cube((-8, 48, 24), (16, 16, 16))]),
        bone('tail2', 'tail1', (0, 58, 40), [cube((-5, 50, 40), (10, 11, 16))]),
        bone('tail3', 'tail2', (0, 56, 56), [cube((-3, 51, 56), (6, 7, 16))]),
        bone('tail4', 'tail3', (0, 55, 72), [cube((-2, 52, 72), (4, 4, 14))]),
        bone('leg_fl', 'root', (10, 44, -12), at(legf, 5, -17)),
        bone('leg_fr', 'root', (-10, 44, -12), at(legf, -15, -17)),
        bone('leg_bl', 'root', (10, 42, 14), at(legb, 5, 9)),
        bone('leg_br', 'root', (-10, 42, 14), at(legb, -15, 9)),
    ]
    pal = dict(dorsal=(112, 126, 100), belly=(176, 180, 148), stripe=False, horn=(190, 185, 150), claw=(60, 55, 45), eye=(210, 160, 50))
    return bones, pal, 'quad', dict(walk_amp=16, run_amp=22, bob=0.4)


def scale_bones(bones, f):
    return [{'name': b['name'], 'parent': b['parent'], 'pivot': [v * f for v in b['pivot']],
             'cubes': [(tuple(v * f for v in o), tuple(v * f for v in sz), k) for (o, sz, k) in b['cubes']]}
            for b in bones]


def species_primordial_rex():
    """Boss: heavier tyrannosaur-like silhouette, swept-back head spikes, blue dorsal crystals. Built at 2x scale."""
    bones, _, kind, params = species_trex()
    by = {b['name']: b for b in bones}
    spine = [(-10, 11), (-4, 15), (2, 13), (8, 10)]
    by['body']['cubes'] += [cube((-2, 58, z), (4, h, 4), 'crystal') for z, h in spine]
    by['neck']['cubes'] += [cube((-1.5, 64, -22), (3, 7, 3), 'crystal')]
    by['tail1']['cubes'] += [cube((-1.5, 56, 16), (3, 8, 3), 'crystal')]
    by['tail2']['cubes'] += [cube((-1, 54, 30), (2, 6, 2), 'crystal')]
    by['head']['cubes'] += [cube((6, 64, -30), (3, 3, 12), 'horn'), cube((-9, 64, -30), (3, 3, 12), 'horn'),
                            cube((-1, 70, -36), (2, 5, 2), 'crystal'), cube((-7, 55, -34), (3, 5, 3), 'horn'),
                            cube((4, 55, -34), (3, 5, 3), 'horn')]
    bones = scale_bones(bones, 2)
    pal = dict(dorsal=(34, 56, 42), belly=(62, 64, 70), stripe=True, horn=(46, 46, 52), claw=(18, 18, 20),
               eye=(90, 225, 255), eye_glow=True)
    return bones, pal, kind, dict(params, walk_amp=18, run_amp=26, bob=1.2)


def boss_extra_anims(ident):
    def a(name, length, loop, bones):
        return (f'animation.{ident}.{name}', {'loop': loop, 'animation_length': length, 'bones': bones})
    t = lambda *xs: list(xs)
    out = dict([
        a('stomp', 1.6, False, {
            'leg_l': {'rotation': kf(t(0, .9, 1.2, 1.4, 1.6), [[0, 0, 0], [-45, 0, 0], [-45, 0, 0], [0, 0, 0], [0, 0, 0]])},
            'body': {'position': kf(t(0, 1.2, 1.4, 1.6), [[0, 0, 0], [0, 12, 0], [0, -6, 0], [0, 0, 0]]),
                     'rotation': kf(t(0, 1.2, 1.4, 1.6), [[0, 0, 0], [-5, 0, 0], [6, 0, 0], [0, 0, 0]])},
            'head': {'rotation': kf(t(0, 1.2, 1.4, 1.6), [[0, 0, 0], [-15, 0, 0], [10, 0, 0], [0, 0, 0]])}}),
        a('tail_sweep', 1.5, False, {
            'body': {'rotation': kf(t(0, 1.0, 1.2, 1.5), [[0, 0, 0], [0, -20, 0], [0, 30, 0], [0, 0, 0]])},
            'tail1': {'rotation': kf(t(0, 1.0, 1.2, 1.5), [[0, 0, 0], [0, -35, 0], [0, 60, 0], [0, 0, 0]])},
            'tail2': {'rotation': kf(t(0, 1.0, 1.2, 1.5), [[0, 0, 0], [0, -45, 0], [0, 75, 0], [0, 0, 0]])},
            'tail3': {'rotation': kf(t(0, 1.0, 1.2, 1.5), [[0, 0, 0], [0, -55, 0], [0, 90, 0], [0, 0, 0]])}}),
        a('charge', 1.5, False, {
            'body': {'rotation': kf(t(0, 1.0, 1.5), [[0, 0, 0], [12, 0, 0], [12, 0, 0]])},
            'head': {'rotation': kf(t(0, 1.0, 1.5), [[0, 0, 0], [20, 0, 0], [20, 0, 0]])},
            'leg_r': {'rotation': kf(t(0, .3, .6, .9, 1.2, 1.5), [[0, 0, 0], [-35, 0, 0], [10, 0, 0], [-35, 0, 0], [10, 0, 0], [0, 0, 0]])}}),
        a('energy_burst', 3.0, False, {
            'head': {'rotation': kf(t(0, 1.2, 2.5, 2.9, 3.0), [[0, 0, 0], [-30, 0, 0], [-30, 0, 0], [5, 0, 0], [0, 0, 0]])},
            'jaw': {'rotation': kf(t(0, 1.2, 1.3, 2.5, 2.9), [[0, 0, 0], [0, 0, 0], [45, 0, 0], [45, 0, 0], [0, 0, 0]])},
            'body': {'rotation': kf(t(0, 1.2, 2.5, 3.0), [[0, 0, 0], [-8, 0, 0], [-8, 0, 0], [0, 0, 0]])},
            'neck': {'rotation': kf(t(0, 1.2, 2.5, 3.0), [[0, 0, 0], [-10, 0, 0], [-10, 0, 0], [0, 0, 0]])}}),
    ])
    return out


SPECIES = {
    'tyrannosaurus': species_trex, 'spinosaurus': species_spinosaurus, 'velociraptor': species_velociraptor,
    'triceratops': species_triceratops, 'brachiosaurus': species_brachiosaurus,
}
EGG_COLORS = {  # base, spots
    'tyrannosaurus': ((190, 180, 140), (110, 95, 60)), 'spinosaurus': ((170, 185, 170), (70, 100, 90)),
    'velociraptor': ((215, 195, 160), (140, 85, 50)), 'triceratops': ((200, 195, 185), (120, 110, 95)),
    'brachiosaurus': ((185, 200, 170), (95, 120, 85)),
}


def make_egg():
    bones = [bone('root', None, (0, 0, 0)), bone('egg', 'root', (0, 0, 0), [
        cube((-3, 0, -3), (6, 2, 6), 'skin'), cube((-4, 2, -4), (8, 5, 8), 'skin'),
        cube((-3, 7, -3), (6, 2, 6), 'skin'), cube((-2, 9, -2), (4, 1, 4), 'skin')])]
    anims = {'format_version': '1.8.0', 'animations': {
        'animation.dino_egg.wobble': {'loop': True, 'animation_length': 3.0, 'bones': {'egg': {
            'rotation': kf([0, .5, 1, 1.5, 3], [[0, 0, 0], [0, 0, 4], [0, 0, -4], [0, 0, 0], [0, 0, 0]])}}},
        'animation.dino_egg.hatch': {'loop': True, 'animation_length': 0.6, 'bones': {'egg': {
            'rotation': kf([0, .15, .3, .45, .6], [[0, 0, 0], [5, 0, 8], [0, 0, 0], [-5, 0, -8], [0, 0, 0]])}}}}}
    return bones, anims


def main():
    for ident, builder in SPECIES.items():
        bones, pal, kind, params = builder()
        seed = sum(ord(c) for c in ident)
        geo, px, glow = build_model(ident, bones, pal, seed)
        write_json(f'{ASSETS}/geo/entity/{ident}.geo.json', geo)
        write_json(f'{ASSETS}/animations/entity/{ident}.animation.json', anim_set(ident, bones, kind, params))
        write_png(f'{ASSETS}/textures/entity/{ident}.png', px)
        print(f'{ident}: {len(bones)} bones, texture {len(px)}px')

    bones, pal, kind, params = species_primordial_rex()
    geo, px, glow = build_model('primordial_rex', bones, pal, 4242)
    anims = anim_set('primordial_rex', bones, kind, params)
    anims['animations'].update(boss_extra_anims('primordial_rex'))
    write_json(f'{ASSETS}/geo/entity/primordial_rex.geo.json', geo)
    write_json(f'{ASSETS}/animations/entity/primordial_rex.animation.json', anims)
    write_png(f'{ASSETS}/textures/entity/primordial_rex.png', px)
    write_png(f'{ASSETS}/textures/entity/primordial_rex_glowmask.png', glow)
    print(f'primordial_rex: {len(bones)} bones, texture {len(px)}px')

    egg_bones, egg_anims = make_egg()
    for ident, (base, spots) in EGG_COLORS.items():
        pal = dict(dorsal=base, belly=shade(base, 0.9), stripe=False, horn=base, claw=base, eye=base)
        geo, px, _ = build_model('dino_egg', egg_bones, pal, 11)
        for y in range(len(px)):
            for x in range(len(px[0])):
                if px[y][x][3] and hnoise(x, y, 99) < 0.12:
                    px[y][x] = spots + (255,)
        write_png(f'{ASSETS}/textures/entity/egg_{ident}.png', px)
    write_json(f'{ASSETS}/geo/entity/dino_egg.geo.json', geo)
    write_json(f'{ASSETS}/animations/entity/dino_egg.animation.json', egg_anims)
    print('egg ok')


if __name__ == '__main__':
    main()
